const express = require('express');

const router = express.Router();
const treatmentController = require('../controllers/treatmentController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

const treatmentRoles = [
    'System Administrator',
    'Risk Committee Chairman',
    'Risk Champion',
    'Risk Focal Person'
];

router.get(
    '/',
    authMiddleware,
    roleMiddleware('System Administrator','Risk Champion'),
    treatmentController.getTreatmentPlans
);

router.post(
    '/',
    authMiddleware,
    roleMiddleware('System Administrator','Risk Champion','Risk Focal Person'),
    treatmentController.createTreatmentPlan
);

router.put(
    '/:id',
    authMiddleware,
    roleMiddleware('System Administrator'),
    treatmentController.updateTreatmentPlan
);

router.delete(
    '/:id',
    authMiddleware,
    roleMiddleware(...treatmentRoles),
    treatmentController.deleteTreatmentPlan
);

module.exports = router;
