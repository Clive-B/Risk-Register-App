const pool = require('../config/db');
const { logAudit } = require('../utils/auditLogger');
const { parseRiskWorkbook } = require('../utils/riskWorkbook');
const { startWorkflow } = require('../services/workflowService');
const { act: performApprovalAction } = require('../services/approvalService');
const { createNotification } = require('../services/notificationService');
const { sendEmail } = require('../services/emailService');
const { createAction, completeBySource } = require('../services/actionService');

const ALLOWED_DIRECTORATES = [
    'RIPS',
    'Legal',
    'Regulatory Administration',
    'Consumer Affairs',
    'Corporate Affairs',
    'Finance',
    'Engineering',
    'Information Technology',
    'Procurement and Protocol',
    'Internal Audit',
    'Human Resource',
    'ROD',
    'Administration',
    'Cybersecurity',
    'International Affairs'
];

const ALLOWED_CATEGORIES = [
    'Strategic',
    'Operational',
    'Financial',
    'Compliance',
    'ICT',
    'Technology',
    'Legal',
    'Cybersecurity',
    'Reputational',
    'Health & Safety',
    'Procurement',
    'Human Resource'
];

const ALLOWED_TREATMENTS = ['Avoid', 'Reduce', 'Transfer', 'Share', 'Accept', 'Fallback'];
const ALLOWED_CONTROL_EFFECTIVENESS = ['Effective', 'Partially Effective', 'Ineffective'];
const ALLOWED_WORKFLOW_STATUSES = ['Draft','Submitted','Under Review','Accepted','Returned','Treatment In Progress','Monitoring','Closed'];
const ALLOWED_TREATMENT_STATUSES = ['Not Started', 'In Progress', 'Completed', 'Deferred'];
const ALLOWED_RISK_STATUSES = ['Draft','Submitted','Under Review','Accepted','Returned','Treatment In Progress','Monitoring','Closed','Open','In Progress','Mitigated'];

function optionalString(value) {
    const text = String(value || '').trim();
    return text || null;
}

function optionalDate(value) {
    return value ? String(value).slice(0, 10) : null;
}

function numberOrNull(value) {
    if (value === null || value === undefined || String(value).trim() === '') return null;
    const number = Number(value);
    return Number.isInteger(number) ? number : null;
}

function normalizeRiskInput(body, user) {
    const impact = Number(body.impact);
    const likelihood = Number(body.likelihood);

    return {
        risk_title: optionalString(body.risk_title),
        risk_description: optionalString(body.risk_description),
        directorate: optionalString(body.directorate) || user.directorate,
        business_unit: optionalString(body.business_unit),
        programme_project: optionalString(body.programme_project),
        risk_category: optionalString(body.risk_category),
        risk_owner: optionalString(body.risk_owner) || user.full_name || user.email,
        date_identified: optionalDate(body.date_identified) || new Date().toISOString().slice(0, 10),
        impact,
        likelihood,
        existing_controls: optionalString(body.existing_controls),
        control_effectiveness: optionalString(body.control_effectiveness),
        risk_treatment: optionalString(body.risk_treatment),
        initial_mitigation_plan: optionalString(body.initial_mitigation_plan),
        responsible_officer: optionalString(body.responsible_officer),
        target_completion_date: optionalDate(body.target_completion_date),
        status: optionalString(body.status),
        workflow_status: optionalString(body.workflow_status) || 'Draft'
    };
}

function calculateRiskLevel(score) {
    if (score >= 20) return 'Critical';
    if (score >= 12) return 'High';
    if (score >= 6) return 'Medium';
    return 'Low';
}

function validateScore(value, label, errors) {
    if (!Number.isInteger(value) || value < 1 || value > 5) {
        errors.push(`${label} must be between 1 and 5.`);
    }
}

function validateRiskInput(risk) {
    const errors = [];

    if (!risk.risk_title) errors.push('Risk title is required.');
    if (!risk.risk_description) errors.push('Risk description is required.');
    if (!ALLOWED_DIRECTORATES.includes(risk.directorate)) errors.push('Select a valid division.');
    if (!ALLOWED_CATEGORIES.includes(risk.risk_category)) errors.push('Select a valid risk category.');
    if (!risk.risk_owner) errors.push('Risk owner is required.');
    validateScore(risk.impact, 'Impact', errors);
    validateScore(risk.likelihood, 'Likelihood', errors);
    if (!risk.existing_controls) errors.push('Existing controls are required.');
    if (!ALLOWED_CONTROL_EFFECTIVENESS.includes(risk.control_effectiveness)) errors.push('Select a valid control effectiveness.');
    if (!ALLOWED_TREATMENTS.includes(risk.risk_treatment)) errors.push('Select a valid risk response.');
    if (!risk.initial_mitigation_plan) errors.push('Initial mitigation plan is required.');
    if (!risk.responsible_officer) errors.push('Responsible officer is required.');
    if (!risk.target_completion_date) errors.push('Target completion date is required.');
    if (!ALLOWED_WORKFLOW_STATUSES.includes(risk.workflow_status)) errors.push('Select a valid workflow status.');

    return errors;
}

function validIsoDate(value) {
    if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const date = new Date(`${value}T00:00:00Z`);
    return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

function normalizeImportedRisk(body, user) {
    const risk = normalizeRiskInput(body, user);
    const optionalNumberFields = [
        'inherent_risk_score',
        'current_impact',
        'current_likelihood',
        'current_risk_score',
        'residual_impact',
        'residual_likelihood',
        'residual_score'
    ];

    risk.risk_id = optionalString(body.risk_id);
    risk.directorate = optionalString(body.directorate);
    risk.risk_owner = optionalString(body.risk_owner);
    risk.inherent_risk_score = numberOrNull(body.inherent_risk_score);
    risk.risk_level = optionalString(body.risk_level);
    risk.business_unit = optionalString(body.business_unit) || user.division;
    risk.programme_project = optionalString(body.programme_project);
    risk.current_impact = numberOrNull(body.current_impact);
    risk.current_likelihood = numberOrNull(body.current_likelihood);
    risk.current_risk_score = numberOrNull(body.current_risk_score);
    risk.treatment_status = optionalString(body.treatment_status) || 'Not Started';
    risk.progress_notes = optionalString(body.progress_notes);
    risk.next_review_date = optionalDate(body.next_review_date);
    risk.residual_impact = numberOrNull(body.residual_impact);
    risk.residual_likelihood = numberOrNull(body.residual_likelihood);
    risk.residual_score = numberOrNull(body.residual_score);
    risk.closure_date = optionalDate(body.closure_date);
    risk.closure_comments = optionalString(body.closure_comments);
    risk.source_status = optionalString(body.status);
    risk.workflow_status = optionalString(body.workflow_status) || 'Draft';
    risk._provided_numbers = new Set(optionalNumberFields.filter(field => body[field] !== null && body[field] !== undefined && String(body[field]).trim() !== ''));
    return risk;
}

function validateImportedRisk(risk, user) {
    const errors = validateRiskInput(risk);
    const calculatedScore = risk.impact * risk.likelihood;
    const calculatedLevel = calculateRiskLevel(calculatedScore);

    if (risk.directorate !== user.directorate) {
        errors.push('Division must match the Risk Focal Person assigned to this import.');
    }
    if (risk.risk_id && risk.risk_id.length > 30) errors.push('Risk ID cannot exceed 30 characters.');
    if (!validIsoDate(risk.date_identified)) errors.push('Date identified must be a valid date.');
    if (!validIsoDate(risk.target_completion_date)) errors.push('Target completion date must be a valid date.');
    if (risk.next_review_date && !validIsoDate(risk.next_review_date)) errors.push('Next review date must be a valid date.');
    if (!['Draft', 'Submitted'].includes(risk.workflow_status)) {
        errors.push('Workflow status must be Draft or Submitted; imports cannot bypass risk approval.');
    }
    if (risk.source_status && !ALLOWED_RISK_STATUSES.includes(risk.source_status)) errors.push('Select a valid risk status.');
    if (risk.closure_date && !validIsoDate(risk.closure_date)) errors.push('Closure date must be a valid date.');
    if (risk._provided_numbers.has('current_impact')) validateScore(risk.current_impact, 'Current impact', errors);
    if (risk._provided_numbers.has('current_likelihood')) validateScore(risk.current_likelihood, 'Current likelihood', errors);
    if (risk._provided_numbers.has('residual_impact')) validateScore(risk.residual_impact, 'Residual impact', errors);
    if (risk._provided_numbers.has('residual_likelihood')) validateScore(risk.residual_likelihood, 'Residual likelihood', errors);
    if (risk._provided_numbers.has('inherent_risk_score') && (!Number.isInteger(risk.inherent_risk_score) || risk.inherent_risk_score < 1 || risk.inherent_risk_score > 25)) {
        errors.push('Inherent risk score must be between 1 and 25.');
    }
    if (risk._provided_numbers.has('current_risk_score') && (!Number.isInteger(risk.current_risk_score) || risk.current_risk_score < 1 || risk.current_risk_score > 25)) {
        errors.push('Current risk score must be between 1 and 25.');
    }
    if (risk._provided_numbers.has('residual_score') && (!Number.isInteger(risk.residual_score) || risk.residual_score < 1 || risk.residual_score > 25)) {
        errors.push('Residual score must be between 1 and 25.');
    }
    if (risk.current_impact && risk.current_likelihood) {
        const score = risk.current_impact * risk.current_likelihood;
        if (risk._provided_numbers.has('current_risk_score') && risk.current_risk_score !== score) {
            errors.push(`Current risk score must equal current impact x current likelihood (${score}).`);
        }
        risk.current_risk_score = score;
    }
    if (risk.residual_impact && risk.residual_likelihood) {
        const score = risk.residual_impact * risk.residual_likelihood;
        if (risk._provided_numbers.has('residual_score') && risk.residual_score !== score) {
            errors.push(`Residual score must equal residual impact x residual likelihood (${score}).`);
        }
        risk.residual_score = score;
    }
    if (risk.inherent_risk_score !== undefined && risk.inherent_risk_score !== null && Number(risk.inherent_risk_score) !== calculatedScore) {
        errors.push(`Inherent risk score must equal impact x likelihood (${calculatedScore}).`);
    }
    if (risk.risk_level && risk.risk_level !== calculatedLevel) {
        errors.push(`Risk level must match the calculated level (${calculatedLevel}).`);
    }
    if (!ALLOWED_TREATMENT_STATUSES.includes(risk.treatment_status)) errors.push('Select a valid treatment status.');

    return [...new Set(errors)];
}

function canAccessDirectorate(user, directorate) {
    if (['System Administrator','Risk Committee Chairman'].includes(user.role)) return true;
    return (user.division || user.directorate) === directorate;
}

function canCreateRisk(user) {
    return ['System Administrator', 'Risk Focal Person'].includes(user.role);
}

function canModifyIdentification(user, risk) {
    if (user.role === 'System Administrator') return true;
    return user.role === 'Risk Focal Person'
        && Number(risk.created_by) === Number(user.id)
        && ['Draft', 'Returned'].includes(risk.workflow_status);
}

function canReviewRisk(user, risk) {
    if (user.role === 'System Administrator') return true;
    return user.role === 'Risk Champion' && user.division === (risk.division || risk.directorate);
}

function canUpdateTreatment(user, risk) {
    if (user.role === 'System Administrator') return true;
    if (user.role === 'Risk Champion') return user.division === (risk.division || risk.directorate) && ['Accepted','Treatment In Progress','Monitoring'].includes(risk.workflow_status);
    return user.role === 'Risk Focal Person'
        && Number(risk.created_by) === Number(user.id)
        && ['Accepted','Treatment In Progress','Monitoring'].includes(risk.workflow_status);
}

function canCloseRisk(user, risk) {
    if (user.role === 'System Administrator') return true;
    if (user.role === 'Risk Committee Chairman') return risk.workflow_status === 'Monitoring' && risk.treatment_status === 'Completed';
    return user.role === 'Risk Champion'
        && user.division === (risk.division || risk.directorate)
        && risk.workflow_status === 'Monitoring' && risk.treatment_status === 'Completed';
}

async function addRiskHistory(client, riskId, action, userId, options = {}) {
    await client.query(
        `
        INSERT INTO risk_history (risk_id, action, from_status, to_status, comment, changed_by, details)
        VALUES ($1,$2,$3,$4,$5,$6,$7)
        `,
        [
            riskId,
            action,
            options.fromStatus || null,
            options.toStatus || null,
            options.comment || null,
            userId || null,
            options.details || {}
        ]
    );
}

async function notifyRiskUsers({req,users,title,message,risk,actionUrl='pages/risks.html'}) {
    await Promise.allSettled(users.map(user => Promise.all([
        createNotification({actor:req.user,req,userId:user.id,title,message,type:'Risk',category:'Risk Governance',priority:risk.risk_level==='Critical'?'Critical':risk.risk_level==='High'?'High':'Normal',entityType:'Risk',entityId:risk.id,createdBy:req.user.id,systemGenerated:true}),
        sendEmail({to:user.email,subject:title,text:message,html:`<p>${message}</p><p><a href="${process.env.FRONTEND_URL||'http://localhost:5500'}/${actionUrl}">Open NCA GRC Platform</a></p>`,emailType:'Risk Governance',userId:user.id,role:user.role,directorate:user.division||user.directorate,sentBy:req.user.id})
    ])));
}

async function notifyRiskSubmitted(req,risk){const users=(await pool.query(`SELECT id,email,role,directorate,division FROM users WHERE role='Risk Champion' AND status='Active' AND COALESCE(NULLIF(division,''),directorate)=$1`,[risk.division||risk.directorate])).rows;await notifyRiskUsers({req,users,title:'Risk Submitted for Review',message:`${risk.risk_id} - ${risk.risk_title} requires division review.`,risk,actionUrl:'pages/pending-approvals.html'});for(const user of users)await createAction({actionKey:`risk-review:${risk.id}:${user.id}`,module:'Risk',actionType:'Review Risk',title:`Review ${risk.risk_id}`,description:risk.risk_title,priority:['Critical','High'].includes(risk.risk_level)?risk.risk_level:'Medium',status:'Waiting for Review',assignedTo:user.id,assignedRole:'Risk Champion',division:risk.division||risk.directorate,assignedBy:req.user.id,dueAt:new Date(Date.now()+72*3600000),sourceType:'RiskReview',sourceId:risk.id,actionUrl:`pages/pending-approvals.html`,availableActions:['review','approve','return','view'],metadata:{riskId:risk.risk_id}},{req})}

async function generateRiskId(client, directorate) {
    const year = new Date().getFullYear();
    const rawCode = String(directorate || 'NCA').split(/\s+/).map(word => word[0]).join('').toUpperCase();
    const code = rawCode.replace(/[^A-Z]/g, '').slice(0, 6) || 'NCA';
    const prefix = `${code}-RSK-${year}-`;
    const result = await client.query(
        `
        SELECT risk_id
        FROM risks
        WHERE risk_id LIKE $1
        ORDER BY risk_id DESC
        LIMIT 1
        `,
        [`${prefix}%`]
    );
    const lastNumber = result.rows.length ? Number(result.rows[0].risk_id.replace(prefix, '')) : 0;
    return `${prefix}${String(lastNumber + 1).padStart(4, '0')}`;
}

async function getRiskById(id) {
    const result = await pool.query('SELECT * FROM risks WHERE id = $1', [id]);
    return result.rows[0] || null;
}

function scopeConditions(req, conditions, params, alias = 'r') {
    if (['System Administrator','Risk Committee Chairman'].includes(req.user.role)) return;
    if (req.user.role === 'Risk Focal Person') { params.push(req.user.division); conditions.push(`${alias}.division = $${params.length}`); return; }
    params.push(req.user.directorate); conditions.push(`${alias}.directorate = $${params.length}`);
}

exports.getRisks = async (req, res) => {
    try {
        const filters = {
            search: optionalString(req.query.search),
            directorate: optionalString(req.query.directorate),
            risk_level: optionalString(req.query.risk_level),
            status: optionalString(req.query.status),
            workflow_status: optionalString(req.query.workflow_status)
        };
        const conditions = [];
        const params = [];

        scopeConditions(req, conditions, params);

        if (['System Administrator','Risk Committee Chairman'].includes(req.user.role) && filters.directorate) {
            params.push(filters.directorate);
            conditions.push(`r.directorate = $${params.length}`);
        }
        if (filters.risk_level) {
            params.push(filters.risk_level);
            conditions.push(`r.risk_level = $${params.length}`);
        }
        if (filters.status) {
            params.push(filters.status);
            conditions.push(`r.status = $${params.length}`);
        }
        if (filters.workflow_status) {
            params.push(filters.workflow_status);
            conditions.push(`r.workflow_status = $${params.length}`);
        }
        if (filters.search) {
            params.push(`%${filters.search.toLowerCase()}%`);
            conditions.push(`(
                LOWER(r.risk_id) LIKE $${params.length}
                OR LOWER(r.risk_title) LIKE $${params.length}
                OR LOWER(r.risk_description) LIKE $${params.length}
                OR LOWER(r.risk_owner) LIKE $${params.length}
            )`);
        }

        const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
        const result = await pool.query(
            `
            SELECT r.*, u.full_name AS created_by_name
            FROM risks r
            LEFT JOIN users u ON u.id = r.created_by
            ${whereClause}
            ORDER BY r.updated_at DESC, r.created_at DESC
            `,
            params
        );

        res.json({ success: true, risks: result.rows });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Unable to load risks.' });
    }
};

exports.createRisk = async (req, res) => {
    const client = await pool.connect();

    try {
        if (!canCreateRisk(req.user)) {
            await logAudit({ req, action: 'RISK_CREATE_DENIED', entityType: 'Risk', status: 'Denied', details: { role: req.user.role } });
            return res.status(403).json({ success: false, message: 'Risk Champions review risks and cannot create new risks.' });
        }

        const risk = normalizeRiskInput(req.body, req.user);

        if (req.user.role === 'Risk Focal Person') {
            risk.directorate = req.user.directorate;
            risk.business_unit = req.user.division;
            risk.risk_owner = req.user.full_name || risk.risk_owner;
        }

        if (!canAccessDirectorate(req.user, risk.directorate)) {
            return res.status(403).json({ success: false, message: 'You can only create risks for your assigned division.' });
        }

        const errors = validateRiskInput(risk);
        if (errors.length) {
            return res.status(400).json({ success: false, message: errors[0], errors });
        }

        const inherentRiskScore = risk.impact * risk.likelihood;
        const workflowStatus = risk.workflow_status === 'Submitted' ? 'Submitted' : 'Draft';
        const status = workflowStatus;

        await client.query('BEGIN');
        const riskId = await generateRiskId(client, risk.directorate);
        const result = await client.query(
            `
            INSERT INTO risks (
                risk_id, risk_title, risk_description, risk_category, directorate, division, business_unit,
                programme_project, risk_owner, date_identified, likelihood, impact, inherent_risk_score,
                residual_risk_score, risk_level, existing_controls, control_effectiveness, risk_treatment,
                initial_mitigation_plan, responsible_officer, target_completion_date, status, workflow_status,
                submitted_at, treatment_status, created_by
            )
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26)
            RETURNING *
            `,
            [
                riskId,
                risk.risk_title,
                risk.risk_description,
                risk.risk_category,
                risk.directorate,
                risk.directorate,
                risk.business_unit,
                risk.programme_project,
                risk.risk_owner,
                risk.date_identified,
                risk.likelihood,
                risk.impact,
                inherentRiskScore,
                null,
                calculateRiskLevel(inherentRiskScore),
                risk.existing_controls,
                risk.control_effectiveness,
                risk.risk_treatment,
                risk.initial_mitigation_plan,
                risk.responsible_officer,
                risk.target_completion_date,
                status,
                workflowStatus,
                workflowStatus === 'Submitted' ? new Date() : null,
                'Not Started',
                req.user.id
            ]
        );

        await addRiskHistory(client, result.rows[0].id, workflowStatus === 'Submitted' ? 'Submitted' : 'Risk Created', req.user.id, {
            toStatus: workflowStatus,
            details: { risk_id: riskId }
        });
        await client.query('COMMIT');

        if (workflowStatus === 'Submitted') {
            await startWorkflow({ workflowKey:'risk_approval', subjectType:'Risk', subjectId:result.rows[0].id, itemTitle:`${riskId} - ${risk.risk_title}`, requesterId:req.user.id, division:risk.directorate, priority:calculateRiskLevel(inherentRiskScore), metadata:{risk_id:riskId} });
            await notifyRiskSubmitted(req,result.rows[0]);
        }

        await logAudit({
            req,
            action: workflowStatus === 'Submitted' ? 'RISK_SUBMITTED' : 'RISK_CREATED',
            entityType: 'Risk',
            entityId: result.rows[0].id,
            details: { risk_id: riskId }
        });
        await completeBySource('RiskReview',risk.id,{actor:req.user,req,comments:`Risk ${workflowStatus}.`});

        res.status(201).json({ success: true, message: 'Risk created successfully.', risk: result.rows[0] });
    } catch (error) {
        await client.query('ROLLBACK').catch(() => {});
        console.error(error);
        res.status(500).json({ success: false, message: 'Unable to create risk.' });
    } finally {
        client.release();
    }
};

async function prepareImportedRows(parsed, user) {
    const rows = parsed.rows.map(row => {
        const risk = normalizeImportedRisk(row.data, user);
        return {
            ...row,
            risk,
            errors: [...row.errors, ...validateImportedRisk(risk, user)]
        };
    });
    const suppliedIds = rows.filter(row => row.risk.risk_id).map(row => row.risk.risk_id.toLowerCase());

    if (suppliedIds.length) {
        const existing = await pool.query('SELECT LOWER(risk_id) AS risk_id FROM risks WHERE LOWER(risk_id) = ANY($1::text[])', [suppliedIds]);
        const existingIds = new Set(existing.rows.map(row => row.risk_id));
        rows.forEach(row => {
            if (row.risk.risk_id && existingIds.has(row.risk.risk_id.toLowerCase())) {
                row.errors.push(`Risk ID ${row.risk.risk_id} already exists.`);
            }
        });
    }

    rows.forEach(row => { row.errors = [...new Set(row.errors)]; });
    return rows;
}

async function insertImportedRisk(client, risk, req, excelRow, fileName) {
    const inherentRiskScore = risk.impact * risk.likelihood;
    const workflowStatus = risk.workflow_status === 'Submitted' ? 'Submitted' : 'Draft';

    await client.query('SELECT pg_advisory_xact_lock(hashtext($1))', [`risk-import:${risk.directorate}`]);
    const riskId = risk.risk_id || await generateRiskId(client, risk.directorate);
    const result = await client.query(
        `
        INSERT INTO risks (
            risk_id, risk_title, risk_description, risk_category, directorate, division, business_unit,
            programme_project, risk_owner, date_identified, likelihood, impact, inherent_risk_score,
            residual_risk_score, risk_level, existing_controls, control_effectiveness, risk_treatment,
            initial_mitigation_plan, responsible_officer, target_completion_date, status, workflow_status,
            submitted_at, treatment_status, created_by, current_impact, current_likelihood,
            current_risk_score, progress_notes, next_review_date, residual_impact, residual_likelihood,
            residual_score, closure_date, closure_comments
        )
        VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,
            $19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36
        )
        RETURNING *
        `,
        [
            riskId,
            risk.risk_title,
            risk.risk_description,
            risk.risk_category,
            risk.directorate,
            risk.directorate,
            risk.business_unit,
            risk.programme_project,
            risk.risk_owner,
            risk.date_identified,
            risk.likelihood,
            risk.impact,
            inherentRiskScore,
            risk.residual_score,
            calculateRiskLevel(inherentRiskScore),
            risk.existing_controls,
            risk.control_effectiveness,
            risk.risk_treatment,
            risk.initial_mitigation_plan,
            risk.responsible_officer,
            risk.target_completion_date,
            risk.source_status || workflowStatus,
            workflowStatus,
            workflowStatus === 'Submitted' ? new Date() : null,
            risk.treatment_status,
            req.user.id,
            risk.current_impact,
            risk.current_likelihood,
            risk.current_risk_score,
            risk.progress_notes,
            risk.next_review_date,
            risk.residual_impact,
            risk.residual_likelihood,
            risk.residual_score,
            risk.closure_date,
            risk.closure_comments
        ]
    );

    const importedRisk = result.rows[0];
    await addRiskHistory(client, importedRisk.id, workflowStatus === 'Submitted' ? 'Submitted' : 'Risk Imported', req.user.id, {
        toStatus: workflowStatus,
        details: { risk_id: riskId, source: 'Excel Import', excel_row: excelRow, file_name: fileName }
    });
    await client.query(
        `
        INSERT INTO audit_logs (
            user_id, user_email, user_role, action, entity_type, entity_id, status,
            ip_address, user_agent, details
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
        `,
        [
            req.user.id,
            req.user.email,
            req.user.role,
            'RISK_IMPORTED',
            'Risk',
            String(importedRisk.id),
            'Success',
            req.ip || null,
            req.headers['user-agent'] || null,
            { risk_id: riskId, excel_row: excelRow, file_name: fileName }
        ]
    );
    return importedRisk;
}

function workbookErrorResponse(res, error) {
    const isInfrastructureError = Boolean(error?.code);
    const message = isInfrastructureError
        ? 'The risk register service is temporarily unable to validate the workbook.'
        : (error && error.message ? error.message : 'Unable to read the Excel workbook.');
    return res.status(isInfrastructureError ? 500 : 400).json({ success: false, message });
}

exports.previewRiskImport = async (req, res) => {
    try {
        const parsed = parseRiskWorkbook(req.body.file_name, req.body.file_data);
        const rows = await prepareImportedRows(parsed, req.user);
        const previewRows = rows.map(row => ({
            excel_row: row.excel_row,
            values: row.values,
            valid: row.errors.length === 0,
            errors: row.errors
        }));
        const validRows = previewRows.filter(row => row.valid).length;

        res.json({
            success: true,
            message: 'Workbook validated. Review the preview before importing.',
            preview: {
                file_name: parsed.file_name,
                sheet_name: parsed.sheet_name,
                header_row: parsed.header_row,
                headers: parsed.headers,
                rows: previewRows,
                summary: {
                    total_rows: previewRows.length,
                    valid_rows: validRows,
                    failed_rows: previewRows.length - validRows,
                    validation_errors: previewRows.flatMap(row => row.errors.map(message => ({ excel_row: row.excel_row, message })))
                }
            }
        });
    } catch (error) {
        console.error('Risk import preview failed:', error.message);
        await logAudit({ req, action: 'RISK_IMPORT_PREVIEW_FAILED', entityType: 'Risk Import', status: 'Failed', details: { file_name: req.body?.file_name, error: error.message } });
        workbookErrorResponse(res, error);
    }
};

exports.importRisks = async (req, res) => {
    try {
        const parsed = parseRiskWorkbook(req.body.file_name, req.body.file_data);
        const rows = await prepareImportedRows(parsed, req.user);
        const validationErrors = [];
        let importedRows = 0;

        for (const row of rows) {
            if (row.errors.length) {
                row.errors.forEach(message => validationErrors.push({ excel_row: row.excel_row, message }));
                continue;
            }

            const client = await pool.connect();
            try {
                await client.query('BEGIN');
                await insertImportedRisk(client, row.risk, req, row.excel_row, parsed.file_name);
                await client.query('COMMIT');
                importedRows += 1;
            } catch (error) {
                await client.query('ROLLBACK').catch(() => {});
                const message = error.code === '23505'
                    ? 'Risk ID already exists.'
                    : 'The row could not be saved to the risk register.';
                validationErrors.push({ excel_row: row.excel_row, message });
                console.error(`Risk import row ${row.excel_row} failed:`, error.message);
            } finally {
                client.release();
            }
        }

        const summary = {
            total_rows: rows.length,
            imported_rows: importedRows,
            failed_rows: rows.length - importedRows,
            validation_errors: validationErrors
        };
        await logAudit({
            req,
            action: 'RISK_IMPORT_COMPLETED',
            entityType: 'Risk Import',
            status: summary.failed_rows ? 'Partial' : 'Success',
            details: {
                file_name: parsed.file_name,
                sheet_name: parsed.sheet_name,
                total_rows: summary.total_rows,
                imported_rows: summary.imported_rows,
                failed_rows: summary.failed_rows,
                validation_error_count: summary.validation_errors.length
            }
        });

        res.status(importedRows ? 201 : 422).json({
            success: importedRows > 0,
            message: importedRows
                ? `${importedRows} risk${importedRows === 1 ? '' : 's'} imported successfully.`
                : 'No risks were imported. Correct the validation errors and try again.',
            summary
        });
    } catch (error) {
        console.error('Risk import failed:', error.message);
        await logAudit({ req, action: 'RISK_IMPORT_FAILED', entityType: 'Risk Import', status: 'Failed', details: { file_name: req.body?.file_name, error: error.message } });
        workbookErrorResponse(res, error);
    }
};

exports.updateRisk = async (req, res) => {
    const client = await pool.connect();

    try {
        const { id } = req.params;
        const existing = await getRiskById(id);

        if (!existing) return res.status(404).json({ success: false, message: 'Risk not found.' });
        if (!canModifyIdentification(req.user, existing)) {
            await logAudit({ req, action: 'RISK_UPDATE_DENIED', entityType: 'Risk', entityId: id, status: 'Denied' });
            return res.status(403).json({ success: false, message: 'You do not have permission to update this risk.' });
        }

        const risk = normalizeRiskInput(req.body, req.user);
        if (req.user.role === 'Risk Focal Person') {
            risk.directorate = req.user.directorate;
            risk.business_unit = req.user.division;
            risk.risk_owner = req.user.full_name || existing.risk_owner;
        }
        if (!canAccessDirectorate(req.user, risk.directorate)) {
            return res.status(403).json({ success: false, message: 'You can only update risks for your assigned division.' });
        }

        const errors = validateRiskInput(risk);
        if (errors.length) return res.status(400).json({ success: false, message: errors[0], errors });

        const inherentRiskScore = risk.impact * risk.likelihood;
        const workflowStatus = risk.workflow_status === 'Submitted' ? 'Submitted' : 'Draft';

        await client.query('BEGIN');
        const result = await client.query(
            `
            UPDATE risks
            SET risk_title = $1,
                risk_description = $2,
                risk_category = $3,
                directorate = $4,
                business_unit = $5,
                programme_project = $6,
                risk_owner = $7,
                date_identified = $8,
                likelihood = $9,
                impact = $10,
                inherent_risk_score = $11,
                risk_level = $12,
                existing_controls = $13,
                control_effectiveness = $14,
                risk_treatment = $15,
                initial_mitigation_plan = $16,
                responsible_officer = $17,
                target_completion_date = $18,
                status = $19,
                workflow_status = $20,
                submitted_at = CASE WHEN $20 = 'Submitted' AND submitted_at IS NULL THEN CURRENT_TIMESTAMP ELSE submitted_at END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $21
            RETURNING *
            `,
            [
                risk.risk_title,
                risk.risk_description,
                risk.risk_category,
                risk.directorate,
                risk.business_unit,
                risk.programme_project,
                risk.risk_owner,
                risk.date_identified,
                risk.likelihood,
                risk.impact,
                inherentRiskScore,
                calculateRiskLevel(inherentRiskScore),
                risk.existing_controls,
                risk.control_effectiveness,
                risk.risk_treatment,
                risk.initial_mitigation_plan,
                risk.responsible_officer,
                risk.target_completion_date,
                workflowStatus,
                workflowStatus,
                id
            ]
        );

        await addRiskHistory(client, id, workflowStatus === 'Submitted' ? 'Submitted' : 'Risk Updated', req.user.id, {
            fromStatus: existing.workflow_status,
            toStatus: workflowStatus,
            details: { risk_id: existing.risk_id }
        });
        await client.query('COMMIT');

        if (workflowStatus === 'Submitted' && existing.workflow_status !== 'Submitted') {
            await startWorkflow({ workflowKey:'risk_approval', subjectType:'Risk', subjectId:id, itemTitle:`${existing.risk_id} - ${risk.risk_title}`, requesterId:req.user.id, division:risk.directorate, priority:calculateRiskLevel(inherentRiskScore), metadata:{risk_id:existing.risk_id} });
            await notifyRiskSubmitted(req,result.rows[0]);
        }

        await logAudit({
            req,
            action: workflowStatus === 'Submitted' ? 'RISK_SUBMITTED' : 'RISK_UPDATED',
            entityType: 'Risk',
            entityId: id,
            details: { risk_id: existing.risk_id, workflow_status: workflowStatus }
        });

        res.json({ success: true, message: 'Risk updated successfully.', risk: result.rows[0] });
    } catch (error) {
        await client.query('ROLLBACK').catch(() => {});
        console.error(error);
        res.status(500).json({ success: false, message: 'Unable to update risk.' });
    } finally {
        client.release();
    }
};

exports.reviewRisk = async (req, res) => {
    try {
        const { id } = req.params;
        const decision = optionalString(req.body.decision);
        const reviewComments = optionalString(req.body.review_comments);
        const decisionMap = { approve: 'Accepted', reject: 'Returned', return: 'Returned' };
        const workflowStatus = decisionMap[decision];

        if (!workflowStatus) return res.status(400).json({ success: false, message: 'Select a valid review decision.' });

        const risk = await getRiskById(id);
        if (!risk) return res.status(404).json({ success: false, message: 'Risk not found.' });
        if (!canReviewRisk(req.user, risk)) {
            await logAudit({ req, action: 'RISK_REVIEW_DENIED', entityType: 'Risk', entityId: id, status: 'Denied' });
            return res.status(403).json({ success: false, message: 'You do not have permission to review this risk.' });
        }
        if (!['Submitted','Under Review'].includes(risk.workflow_status)) {
            return res.status(400).json({ success: false, message: 'Only submitted risks under review can be actioned.' });
        }

        let workflow=(await pool.query(`SELECT id FROM workflow_instances WHERE subject_type='Risk' AND subject_id=$1 AND status IN('Pending','Under Review','Escalated') ORDER BY created_at DESC LIMIT 1`,[String(id)])).rows[0];
        if(!workflow) workflow=await startWorkflow({workflowKey:'risk_approval',subjectType:'Risk',subjectId:id,itemTitle:`${risk.risk_id} - ${risk.risk_title}`,requesterId:risk.created_by,division:risk.division||risk.directorate,priority:risk.risk_level,metadata:{risk_id:risk.risk_id}});
        await performApprovalAction({instanceId:workflow.id,action:decision,comments:reviewComments,req});
        const result = await pool.query(
            `
            UPDATE risks
            SET workflow_status = $1,
                reviewed_at = CURRENT_TIMESTAMP,
                reviewed_by = $2,
                review_comments = $3,
                status = CASE
                    WHEN $1 = 'Accepted' THEN 'Accepted'
                    ELSE 'Returned'
                END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $4
            RETURNING *
            `,
            [workflowStatus, req.user.id, reviewComments, id]
        );
        await pool.query(
            'INSERT INTO risk_reviews (risk_id, decision, review_comment, reviewed_by) VALUES ($1,$2,$3,$4)',
            [id, workflowStatus, reviewComments, req.user.id]
        );
        const historyClient=await pool.connect();
        try {
        if(risk.workflow_status==='Submitted')await addRiskHistory(historyClient, id, 'Under Review', req.user.id, {fromStatus:'Submitted',toStatus:'Under Review',comment:reviewComments,details:{risk_id:risk.risk_id}});
        await addRiskHistory(historyClient, id, workflowStatus, req.user.id, {
            fromStatus: 'Under Review',
            toStatus: workflowStatus,
            comment: reviewComments,
            details: { risk_id: risk.risk_id }
        }); } finally { historyClient.release(); }

        await logAudit({
            req,
            action: `RISK_${workflowStatus.toUpperCase().replaceAll(' ', '_')}`,
            entityType: 'Risk',
            entityId: id,
            details: { risk_id: risk.risk_id, review_comments: reviewComments }
        });

        const requester=(await pool.query('SELECT id,email,role,directorate,division FROM users WHERE id=$1',[risk.created_by])).rows;
        await notifyRiskUsers({req,users:requester,title:`Risk ${workflowStatus}`,message:`${risk.risk_id} - ${risk.risk_title} was ${workflowStatus.toLowerCase()} by the Risk Champion.`,risk:result.rows[0]});
        if(workflowStatus==='Accepted'&&['High','Critical'].includes(risk.risk_level)){
            const chairmen=(await pool.query(`SELECT id,email,role,directorate,division FROM users WHERE role='Risk Committee Chairman' AND status='Active'`)).rows;
            await notifyRiskUsers({req,users:chairmen,title:'High/Critical Risk Escalation',message:`${risk.risk_id} - ${risk.risk_title} was accepted and requires committee visibility.`,risk:result.rows[0]});
            for(const chairman of chairmen)await createAction({actionKey:`committee-review:${risk.id}:${chairman.id}`,module:'Risk',actionType:'Executive Review',title:`Committee review: ${risk.risk_id}`,description:risk.risk_title,priority:risk.risk_level,status:'Escalated',assignedTo:chairman.id,assignedRole:'Risk Committee Chairman',assignedBy:req.user.id,sourceType:'CommitteeReview',sourceId:risk.id,actionUrl:'pages/pending-approvals.html',availableActions:['review','approve','return','view'],metadata:{riskId:risk.risk_id}},{req});
        }
        if(workflowStatus==='Returned'&&requester[0])await createAction({actionKey:`risk-correction:${risk.id}:${requester[0].id}:${Date.now()}`,module:'Risk',actionType:'Update Risk',title:`Correct and resubmit ${risk.risk_id}`,description:reviewComments||risk.risk_title,priority:risk.risk_level==='Critical'?'Critical':'High',status:'Returned',assignedTo:requester[0].id,assignedBy:req.user.id,division:risk.division||risk.directorate,sourceType:'RiskCorrection',sourceId:risk.id,actionUrl:`pages/create-risk.html?id=${risk.id}`,availableActions:['update','continue','view']},{req});

        res.json({ success: true, message: `Risk ${workflowStatus.toLowerCase()} successfully.`, risk: result.rows[0] });
    } catch (error) {
        console.error(error);
        res.status(error.statusCode||500).json({ success: false, message: error.statusCode?error.message:'Unable to review risk.' });
    }
};

exports.startRiskReview=async(req,res)=>{try{const risk=await getRiskById(req.params.id);if(!risk)return res.status(404).json({success:false,message:'Risk not found.'});if(!canReviewRisk(req.user,risk))return res.status(403).json({success:false,message:'You may only review risks in your assigned division.'});if(risk.workflow_status==='Under Review')return res.json({success:true,risk});if(risk.workflow_status!=='Submitted')return res.status(409).json({success:false,message:'Only submitted risks can enter review.'});const result=await pool.query(`UPDATE risks SET workflow_status='Under Review',status='Under Review',updated_at=NOW() WHERE id=$1 RETURNING *`,[risk.id]);await pool.query(`INSERT INTO risk_history(risk_id,action,from_status,to_status,changed_by,details) VALUES($1,'Under Review','Submitted','Under Review',$2,$3)`,[risk.id,req.user.id,{risk_id:risk.risk_id}]);await logAudit({req,action:'RISK_UNDER_REVIEW',entityType:'Risk',entityId:risk.id,details:{risk_id:risk.risk_id}});res.json({success:true,risk:result.rows[0]})}catch(e){console.error(e);res.status(500).json({success:false,message:'Unable to start risk review.'})}};

exports.committeeReview = async (req,res) => {
    const client=await pool.connect();
    try{
        const risk=await getRiskById(req.params.id);if(!risk)return res.status(404).json({success:false,message:'Risk not found.'});
        if(!['High','Critical'].includes(risk.risk_level))return res.status(400).json({success:false,message:'Committee review is limited to High and Critical risks.'});
        if(!['Accepted','Under Review'].includes(risk.workflow_status))return res.status(409).json({success:false,message:'Only accepted or escalated risks can receive committee review.'});
        const action=String(req.body.action||'').toLowerCase(),comments=optionalString(req.body.comments),recommendations=optionalString(req.body.recommendations);
        if(!['approve','return','recommend'].includes(action))return res.status(400).json({success:false,message:'Select approve, return, or recommend.'});
        if(!comments)return res.status(400).json({success:false,message:'Executive comments are required.'});
        const nextStatus=action==='return'?'Returned':'Accepted';await client.query('BEGIN');
        const result=await client.query(`UPDATE risks SET workflow_status=$1,status=$1,committee_recommendations=COALESCE($2,committee_recommendations),executive_comments=$3,committee_reviewed_by=$4,committee_reviewed_at=NOW(),updated_at=NOW() WHERE id=$5 RETURNING *`,[nextStatus,recommendations,comments,req.user.id,risk.id]);
        await addRiskHistory(client,risk.id,action==='return'?'Risk Returned':'Committee Review',req.user.id,{fromStatus:risk.workflow_status,toStatus:nextStatus,comment:comments,details:{recommendations}});await client.query('COMMIT');
        await logAudit({req,action:action==='return'?'RISK_RETURNED':'RISK_COMMITTEE_REVIEWED',entityType:'Risk',entityId:risk.id,details:{risk_id:risk.risk_id,recommendations}});
        const requester=(await pool.query('SELECT id,email,role,directorate,division FROM users WHERE id=$1',[risk.created_by])).rows;await notifyRiskUsers({req,users:requester,title:`Committee Review: ${nextStatus}`,message:`${risk.risk_id} - ${risk.risk_title}: ${comments}`,risk:result.rows[0]});
        res.json({success:true,message:'Committee review recorded.',risk:result.rows[0]});
    }catch(e){await client.query('ROLLBACK').catch(()=>{});console.error(e);res.status(500).json({success:false,message:'Unable to record committee review.'})}finally{client.release()}
};

exports.addTreatmentUpdate = async (req, res) => {
    const client = await pool.connect();

    try {
        const { id } = req.params;
        const risk = await getRiskById(id);
        if (!risk) return res.status(404).json({ success: false, message: 'Risk not found.' });
        if (!canUpdateTreatment(req.user, risk)) {
            return res.status(403).json({ success: false, message: 'You do not have permission to update monitoring for this risk.' });
        }

        const currentImpact = numberOrNull(req.body.current_impact);
        const currentLikelihood = numberOrNull(req.body.current_likelihood);
        const residualImpact = numberOrNull(req.body.residual_impact);
        const residualLikelihood = numberOrNull(req.body.residual_likelihood);
        const treatmentStatus = optionalString(req.body.treatment_status) || 'In Progress';

        if (currentImpact !== null && (currentImpact < 1 || currentImpact > 5)) {
            return res.status(400).json({ success: false, message: 'Current impact must be between 1 and 5.' });
        }
        if (currentLikelihood !== null && (currentLikelihood < 1 || currentLikelihood > 5)) {
            return res.status(400).json({ success: false, message: 'Current likelihood must be between 1 and 5.' });
        }
        if (!ALLOWED_TREATMENT_STATUSES.includes(treatmentStatus)) {
            return res.status(400).json({ success: false, message: 'Select a valid treatment status.' });
        }
        if ((residualImpact === null) !== (residualLikelihood === null)) {
            return res.status(400).json({ success: false, message: 'Residual impact and residual likelihood are required together.' });
        }

        const currentRiskScore = currentImpact && currentLikelihood ? currentImpact * currentLikelihood : null;
        const residualScore = residualImpact && residualLikelihood ? residualImpact * residualLikelihood : null;

        await client.query('BEGIN');
        await client.query(
            `
            INSERT INTO risk_treatment_updates (
                risk_id, current_impact, current_likelihood, current_risk_score, progress_notes,
                treatment_status, review_date, residual_impact, residual_likelihood, residual_score, updated_by
            )
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
            `,
            [
                id,
                currentImpact,
                currentLikelihood,
                currentRiskScore,
                optionalString(req.body.progress_notes),
                treatmentStatus,
                optionalDate(req.body.review_date),
                residualImpact,
                residualLikelihood,
                residualScore,
                req.user.id
            ]
        );
        const result = await client.query(
            `
            UPDATE risks
            SET current_impact = COALESCE($1, current_impact),
                current_likelihood = COALESCE($2, current_likelihood),
                current_risk_score = COALESCE($3, current_risk_score),
                progress_notes = $4,
                treatment_status = $5,
                next_review_date = $6,
                residual_impact = COALESCE($7, residual_impact),
                residual_likelihood = COALESCE($8, residual_likelihood),
                residual_score = COALESCE($9, residual_score),
                residual_risk_score = COALESCE($9, residual_risk_score),
                status = CASE WHEN $5 = 'Completed' THEN 'Monitoring' ELSE 'Treatment In Progress' END,
                workflow_status = CASE WHEN $5 = 'Completed' THEN 'Monitoring' ELSE 'Treatment In Progress' END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $10
            RETURNING *
            `,
            [
                currentImpact,
                currentLikelihood,
                currentRiskScore,
                optionalString(req.body.progress_notes),
                treatmentStatus,
                optionalDate(req.body.review_date),
                residualImpact,
                residualLikelihood,
                residualScore,
                id
            ]
        );
        await addRiskHistory(client, id, treatmentStatus==='Completed'?'Treatment Completed':'Treatment Updated', req.user.id, {
            fromStatus:risk.workflow_status,
            toStatus:treatmentStatus==='Completed'?'Monitoring':'Treatment In Progress',
            comment: optionalString(req.body.progress_notes),
            details: { treatment_status: treatmentStatus, residual_score: residualScore }
        });
        await client.query('COMMIT');

        await logAudit({ req, action: treatmentStatus==='Completed'?'TREATMENT_COMPLETED':'TREATMENT_UPDATED', entityType: 'Risk', entityId: id, details: { risk_id: risk.risk_id, treatment_status: treatmentStatus } });
        if(treatmentStatus==='Completed'){
            const stakeholders=(await pool.query(`SELECT DISTINCT u.id,u.email,u.role,u.directorate,u.division FROM users u WHERE u.status='Active' AND (u.id=$1 OR (u.role='Risk Champion' AND COALESCE(NULLIF(u.division,''),u.directorate)=$2) OR u.role='Risk Committee Chairman')`,[risk.created_by,risk.division||risk.directorate])).rows;
            await notifyRiskUsers({req,users:stakeholders,title:'Treatment Completed',message:`Treatment for ${risk.risk_id} - ${risk.risk_title} is complete and the risk is now under monitoring.`,risk:result.rows[0]});
        }
        res.json({ success: true, message: 'Risk monitoring update saved.', risk: result.rows[0] });
    } catch (error) {
        await client.query('ROLLBACK').catch(() => {});
        console.error(error);
        res.status(500).json({ success: false, message: 'Unable to save monitoring update.' });
    } finally {
        client.release();
    }
};

exports.closeRisk = async (req, res) => {
    const client = await pool.connect();

    try {
        const { id } = req.params;
        const risk = await getRiskById(id);
        if (!risk) return res.status(404).json({ success: false, message: 'Risk not found.' });
        if (!canCloseRisk(req.user, risk)) {
            return res.status(403).json({ success: false, message: 'You do not have permission to close this risk.' });
        }

        const closureComments = optionalString(req.body.closure_comments);
        if (!closureComments) return res.status(400).json({ success: false, message: 'Closure comments are required.' });

        await client.query('BEGIN');
        const result = await client.query(
            `
            UPDATE risks
            SET status = 'Closed',
                workflow_status = 'Closed',
                closure_date = COALESCE($1, CURRENT_DATE),
                closure_comments = $2,
                closed_by = $3,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $4
            RETURNING *
            `,
            [optionalDate(req.body.closure_date), closureComments, req.user.id, id]
        );
        await addRiskHistory(client, id, 'Closed', req.user.id, {
            fromStatus: risk.workflow_status,
            toStatus: 'Closed',
            comment: closureComments,
            details: { risk_id: risk.risk_id }
        });
        await client.query('COMMIT');

        await logAudit({ req, action: 'RISK_CLOSED', entityType: 'Risk', entityId: id, details: { risk_id: risk.risk_id } });
        res.json({ success: true, message: 'Risk closed successfully.', risk: result.rows[0] });
    } catch (error) {
        await client.query('ROLLBACK').catch(() => {});
        console.error(error);
        res.status(500).json({ success: false, message: 'Unable to close risk.' });
    } finally {
        client.release();
    }
};

exports.deleteRisk = exports.closeRisk;

exports.getRiskHistory = async (req, res) => {
    try {
        const risk = await getRiskById(req.params.id);
        if (!risk) return res.status(404).json({ success: false, message: 'Risk not found.' });
        if (!canAccessDirectorate(req.user, risk.directorate)) {
            return res.status(403).json({ success: false, message: 'You do not have permission to view this history.' });
        }

        const [history, reviews, updates] = await Promise.all([
            pool.query(
                `SELECT h.*, u.full_name AS changed_by_name FROM risk_history h LEFT JOIN users u ON u.id = h.changed_by WHERE h.risk_id = $1 ORDER BY h.changed_at DESC`,
                [req.params.id]
            ),
            pool.query(
                `SELECT rr.*, u.full_name AS reviewed_by_name FROM risk_reviews rr LEFT JOIN users u ON u.id = rr.reviewed_by WHERE rr.risk_id = $1 ORDER BY rr.reviewed_at DESC`,
                [req.params.id]
            ),
            pool.query(
                `SELECT rtu.*, u.full_name AS updated_by_name FROM risk_treatment_updates rtu LEFT JOIN users u ON u.id = rtu.updated_by WHERE rtu.risk_id = $1 ORDER BY rtu.created_at DESC`,
                [req.params.id]
            )
        ]);

        res.json({ success: true, history: history.rows, reviews: reviews.rows, treatment_updates: updates.rows });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Unable to load risk history.' });
    }
};

exports.getAttachments = async (req, res) => {
    try {
        const risk = await getRiskById(req.params.id);
        if (!risk) return res.status(404).json({ success: false, message: 'Risk not found.' });
        if (!canAccessDirectorate(req.user, risk.directorate)) {
            return res.status(403).json({ success: false, message: 'You do not have permission to view attachments.' });
        }

        const result = await pool.query(
            `
            SELECT id, risk_id, file_name, file_type, file_size, uploaded_by, uploaded_at
            FROM risk_attachments
            WHERE risk_id = $1
            ORDER BY uploaded_at DESC
            `,
            [req.params.id]
        );
        res.json({ success: true, attachments: result.rows });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Unable to load attachments.' });
    }
};

exports.addAttachment = async (req, res) => {
    const client = await pool.connect();

    try {
        const risk = await getRiskById(req.params.id);
        if (!risk) return res.status(404).json({ success: false, message: 'Risk not found.' });
        if (!canAccessDirectorate(req.user, risk.directorate)) {
            return res.status(403).json({ success: false, message: 'You do not have permission to upload attachments.' });
        }

        const fileName = optionalString(req.body.file_name);
        const fileType = optionalString(req.body.file_type);
        const fileData = optionalString(req.body.file_data);
        const fileSize = Number(req.body.file_size) || null;

        if (!fileName || !fileData) {
            return res.status(400).json({ success: false, message: 'Attachment file name and data are required.' });
        }

        const allowedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'image/png',
            'image/jpeg',
            'image/gif',
            'image/webp'
        ];

        if (fileType && !allowedTypes.includes(fileType)) {
            return res.status(400).json({ success: false, message: 'Only PDF, Word, Excel, and image attachments are allowed.' });
        }

        const base64 = fileData.includes(',') ? fileData.split(',').pop() : fileData;
        const buffer = Buffer.from(base64, 'base64');

        await client.query('BEGIN');
        const result = await client.query(
            `
            INSERT INTO risk_attachments (risk_id, file_name, file_type, file_size, file_data, uploaded_by)
            VALUES ($1,$2,$3,$4,$5,$6)
            RETURNING id, risk_id, file_name, file_type, file_size, uploaded_by, uploaded_at
            `,
            [req.params.id, fileName, fileType, fileSize || buffer.length, buffer, req.user.id]
        );
        await addRiskHistory(client, req.params.id, 'Attachment Added', req.user.id, {
            details: { file_name: fileName }
        });
        await client.query('COMMIT');

        await logAudit({ req, action: 'RISK_UPDATED', entityType: 'Risk', entityId: req.params.id, details: { risk_id: risk.risk_id, attachment: fileName } });
        res.status(201).json({ success: true, message: 'Attachment uploaded successfully.', attachment: result.rows[0] });
    } catch (error) {
        await client.query('ROLLBACK').catch(() => {});
        console.error(error);
        res.status(500).json({ success: false, message: 'Unable to upload attachment.' });
    } finally {
        client.release();
    }
};
