const pool = require('../config/db');
const { logAudit } = require('../utils/auditLogger');
const { createNotification } = require('../services/notificationService');
const { sendEmail } = require('../services/emailService');
const { createAction, completeBySource } = require('../services/actionService');

async function notifyTreatment(req,riskId,title,message){const users=(await pool.query(`SELECT DISTINCT u.id,u.email,u.role,u.division,u.directorate FROM risks r JOIN users u ON u.status='Active' AND (u.id=r.created_by OR (u.role='Risk Champion' AND COALESCE(NULLIF(u.division,''),u.directorate)=COALESCE(NULLIF(r.division,''),r.directorate)) OR u.role='Risk Committee Chairman') WHERE r.id=$1`,[riskId])).rows;await Promise.allSettled(users.map(u=>Promise.all([createNotification({actor:req.user,req,userId:u.id,title,message,type:'Risk',category:'Treatment',priority:'Normal',entityType:'Risk',entityId:riskId,createdBy:req.user.id,systemGenerated:true}),sendEmail({to:u.email,subject:title,text:message,html:`<p>${message}</p>`,emailType:'Treatment',userId:u.id,role:u.role,directorate:u.division||u.directorate,sentBy:req.user.id})])))}

const ALLOWED_STRATEGIES = ['Avoid', 'Reduce', 'Transfer', 'Accept'];
const ALLOWED_STATUSES = ['Not Started', 'In Progress', 'Completed', 'Overdue'];

function normalizeTreatmentInput(body) {
    return {
        risk_id: Number(body.risk_id),
        plan_title: String(body.plan_title || '').trim(),
        treatment_strategy: String(body.treatment_strategy || '').trim(),
        action_owner: String(body.action_owner || '').trim(),
        due_date: String(body.due_date || '').trim(),
        progress_percent: Number(body.progress_percent),
        status: String(body.status || 'Not Started').trim(),
        evidence_file_name: String(body.evidence_file_name || '').trim(),
        evidence_url: String(body.evidence_url || '').trim(),
        evidence_notes: String(body.evidence_notes || '').trim()
    };
}

function validateTreatmentInput(plan) {
    const errors = [];

    if (!Number.isInteger(plan.risk_id)) errors.push('Select a valid risk.');
    if (!plan.plan_title) errors.push('Treatment plan title is required.');
    if (!ALLOWED_STRATEGIES.includes(plan.treatment_strategy)) errors.push('Select a valid treatment strategy.');
    if (!plan.action_owner) errors.push('Action owner is required.');
    if (!plan.due_date || Number.isNaN(Date.parse(plan.due_date))) errors.push('Valid due date is required.');
    if (!Number.isInteger(plan.progress_percent) || plan.progress_percent < 0 || plan.progress_percent > 100) {
        errors.push('Progress must be between 0 and 100.');
    }
    if (!ALLOWED_STATUSES.includes(plan.status)) errors.push('Select a valid status.');
    if (plan.evidence_url && !/^https?:\/\/|^file:\/\/|^[\w .:/\\-]+$/i.test(plan.evidence_url)) {
        errors.push('Enter a valid evidence reference.');
    }

    return errors;
}

function deriveStatus(plan) {
    if (plan.progress_percent === 100) return 'Completed';
    if (plan.due_date && new Date(plan.due_date) < startOfToday()) return 'Overdue';
    if (plan.progress_percent > 0) return 'In Progress';
    return plan.status === 'Overdue' ? 'Not Started' : plan.status;
}

function startOfToday() {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return today;
}

function canAccessRisk(user, risk) {
    if (['System Administrator','Risk Committee Chairman'].includes(user.role)) return true;
    return user.division === (risk.division || risk.directorate);
}

function canModifyPlan(user, plan) {
    if (user.role === 'System Administrator') return true;
    if (user.role === 'Risk Champion') return user.division === (plan.division || plan.directorate);
    if (user.role === 'Risk Focal Person') {
        return user.division === plan.division;
    }
    return false;
}

async function getRiskForAccess(riskId) {
    const result = await pool.query(
        'SELECT id, directorate, division, created_by FROM risks WHERE id = $1',
        [riskId]
    );

    return result.rows[0];
}

exports.getTreatmentPlans = async (req, res) => {
    try {
        const filters = {
            search: String(req.query.search || '').trim().toLowerCase(),
            status: String(req.query.status || '').trim(),
            directorate: String(req.query.directorate || '').trim()
        };

        const conditions = [];
        const params = [];

        if (req.user.role === 'Risk Focal Person') {
            params.push(req.user.division);
            conditions.push(`r.division = $${params.length}`);
        } else if (req.user.role === 'Risk Champion') {
            params.push(req.user.division);
            conditions.push(`COALESCE(NULLIF(r.division,''),r.directorate) = $${params.length}`);
        } else if (filters.directorate) {
            params.push(filters.directorate);
            conditions.push(`r.directorate = $${params.length}`);
        }

        if (filters.status) {
            params.push(filters.status);
            conditions.push(`tp.status = $${params.length}`);
        }

        if (filters.search) {
            params.push(`%${filters.search}%`);
            conditions.push(`(
                LOWER(tp.plan_title) LIKE $${params.length}
                OR LOWER(tp.action_owner) LIKE $${params.length}
                OR LOWER(r.risk_id) LIKE $${params.length}
                OR LOWER(r.risk_title) LIKE $${params.length}
            )`);
        }

        const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

        const result = await pool.query(
            `
            SELECT
                tp.*,
                r.risk_id AS risk_code,
                r.risk_title,
                r.directorate,
                r.division,
                r.risk_level,
                u.full_name AS created_by_name,
                (tp.due_date < CURRENT_DATE AND tp.progress_percent < 100) AS is_overdue
            FROM treatment_plans tp
            INNER JOIN risks r ON r.id = tp.risk_id
            LEFT JOIN users u ON u.id = tp.created_by
            ${whereClause}
            ORDER BY tp.due_date ASC, tp.updated_at DESC
            `,
            params
        );

        await pool.query(`UPDATE risks SET workflow_status='Treatment In Progress',status='Treatment In Progress',treatment_status=$2,updated_at=NOW() WHERE id=$1`,[plan.risk_id,status]);
        await logAudit({req,action:'TREATMENT_ASSIGNED',entityType:'Risk',entityId:plan.risk_id,details:{treatment_plan_id:result.rows[0].id,action_owner:plan.action_owner}});
        await notifyTreatment(req,plan.risk_id,'Treatment Plan Assigned',`${plan.plan_title} was assigned to ${plan.action_owner}.`);
        if(risk.created_by)await createAction({actionKey:`treatment:${result.rows[0].id}:${risk.created_by}`,module:'Treatment',actionType:'Update Treatment',title:plan.plan_title,description:`Treatment assigned for risk ${plan.risk_id}.`,priority:'High',status:'Pending',assignedTo:risk.created_by,assignedBy:req.user.id,division:risk.division||risk.directorate,dueAt:plan.due_date,sourceType:'TreatmentPlan',sourceId:result.rows[0].id,actionUrl:'pages/treatment.html',availableActions:['update','upload','complete','view'],emailEnabled:true},{req});

        res.json({
            success: true,
            treatmentPlans: result.rows
        });
    } catch (error) {
        console.error(error);

        res.status(500).json({
            success: false,
            message: 'Unable to load treatment plans.'
        });
    }
};

exports.createTreatmentPlan = async (req, res) => {
    try {
        const plan = normalizeTreatmentInput(req.body);
        const errors = validateTreatmentInput(plan);

        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                message: errors[0],
                errors
            });
        }

        const risk = await getRiskForAccess(plan.risk_id);

        if (!risk) {
            return res.status(404).json({
                success: false,
                message: 'Risk not found.'
            });
        }

        if (!canAccessRisk(req.user, risk)) {
            return res.status(403).json({
                success: false,
                message: 'You can only create treatment plans for risks in your assigned division.'
            });
        }

        const status = deriveStatus(plan);
        const result = await pool.query(
            `
            INSERT INTO treatment_plans (
                risk_id,
                plan_title,
                treatment_strategy,
                action_owner,
                due_date,
                progress_percent,
                status,
                evidence_file_name,
                evidence_url,
                evidence_notes,
                created_by
            )
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
            RETURNING *
            `,
            [
                plan.risk_id,
                plan.plan_title,
                plan.treatment_strategy,
                plan.action_owner,
                plan.due_date,
                plan.progress_percent,
                status,
                plan.evidence_file_name,
                plan.evidence_url,
                plan.evidence_notes,
                req.user.id
            ]
        );

        await pool.query(`UPDATE risks SET workflow_status=CASE WHEN $2='Completed' THEN 'Monitoring' ELSE 'Treatment In Progress' END,status=CASE WHEN $2='Completed' THEN 'Monitoring' ELSE 'Treatment In Progress' END,treatment_status=$2,updated_at=NOW() WHERE id=$1`,[plan.risk_id,status]);
        await logAudit({req,action:status==='Completed'?'TREATMENT_COMPLETED':'TREATMENT_UPDATED',entityType:'Risk',entityId:plan.risk_id,details:{treatment_plan_id:id,status}});
        if(status==='Completed')await notifyTreatment(req,plan.risk_id,'Treatment Completed',`${plan.plan_title} has been completed and moved to monitoring.`);
        if(status==='Completed')await completeBySource('TreatmentPlan',id,{actor:req.user,req,comments:'Treatment plan completed.'});

        res.status(201).json({
            success: true,
            message: 'Treatment plan created successfully.',
            treatmentPlan: result.rows[0]
        });
    } catch (error) {
        console.error(error);

        res.status(500).json({
            success: false,
            message: 'Unable to create treatment plan.'
        });
    }
};

exports.updateTreatmentPlan = async (req, res) => {
    try {
        const { id } = req.params;
        const plan = normalizeTreatmentInput(req.body);
        const errors = validateTreatmentInput(plan);

        if (errors.length > 0) {
            return res.status(400).json({
                success: false,
                message: errors[0],
                errors
            });
        }

        const existing = await pool.query(
            `
            SELECT tp.id, tp.created_by, r.directorate, r.division
            FROM treatment_plans tp
            INNER JOIN risks r ON r.id = tp.risk_id
            WHERE tp.id = $1
            `,
            [id]
        );

        if (existing.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Treatment plan not found.'
            });
        }

        const risk = await getRiskForAccess(plan.risk_id);

        if (!risk) {
            return res.status(404).json({
                success: false,
                message: 'Risk not found.'
            });
        }

        if (!canModifyPlan(req.user, existing.rows[0]) || !canAccessRisk(req.user, risk)) {
            return res.status(403).json({
                success: false,
                message: 'You do not have permission to update this treatment plan.'
            });
        }

        const status = deriveStatus(plan);
        const result = await pool.query(
            `
            UPDATE treatment_plans
            SET
                risk_id = $1,
                plan_title = $2,
                treatment_strategy = $3,
                action_owner = $4,
                due_date = $5,
                progress_percent = $6,
                status = $7,
                evidence_file_name = $8,
                evidence_url = $9,
                evidence_notes = $10,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $11
            RETURNING *
            `,
            [
                plan.risk_id,
                plan.plan_title,
                plan.treatment_strategy,
                plan.action_owner,
                plan.due_date,
                plan.progress_percent,
                status,
                plan.evidence_file_name,
                plan.evidence_url,
                plan.evidence_notes,
                id
            ]
        );

        res.json({
            success: true,
            message: 'Treatment plan updated successfully.',
            treatmentPlan: result.rows[0]
        });
    } catch (error) {
        console.error(error);

        res.status(500).json({
            success: false,
            message: 'Unable to update treatment plan.'
        });
    }
};

exports.deleteTreatmentPlan = async (req, res) => {
    try {
        const { id } = req.params;

        const existing = await pool.query(
            `
            SELECT tp.id, tp.created_by, r.directorate, r.division
            FROM treatment_plans tp
            INNER JOIN risks r ON r.id = tp.risk_id
            WHERE tp.id = $1
            `,
            [id]
        );

        if (existing.rows.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Treatment plan not found.'
            });
        }

        if (!canModifyPlan(req.user, existing.rows[0])) {
            return res.status(403).json({
                success: false,
                message: 'You do not have permission to delete this treatment plan.'
            });
        }

        await pool.query('DELETE FROM treatment_plans WHERE id = $1', [id]);

        res.json({
            success: true,
            message: 'Treatment plan deleted successfully.'
        });
    } catch (error) {
        console.error(error);

        res.status(500).json({
            success: false,
            message: 'Unable to delete treatment plan.'
        });
    }
};
