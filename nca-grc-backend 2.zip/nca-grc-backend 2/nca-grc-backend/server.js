require('dotenv').config();

const express = require('express');
let helmet;
let rateLimit;
try { helmet = require('helmet'); } catch (_) { helmet = () => (_req,_res,next) => next(); }
try { rateLimit = require('express-rate-limit'); } catch (_) { rateLimit = () => (_req,_res,next) => next(); }
const pool = require('./config/db');

const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const riskRoutes = require('./routes/risks');
const treatmentRoutes = require('./routes/treatments');
const auditRoutes = require('./routes/auditRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const communicationRoutes = require('./routes/communicationRoutes');
const centerRoutes = require('./routes/centerRoutes');
const workflowRoutes = require('./routes/workflowRoutes');
const executiveAnalyticsRoutes = require('./routes/executiveAnalyticsRoutes');
const actionRoutes = require('./routes/actionRoutes');
const authMiddleware = require('./middleware/authMiddleware');


const allowedOrigins = (process.env.CORS_ORIGINS || 'http://localhost:5500,http://127.0.0.1:5500,http://localhost:5501,http://127.0.0.1:5501')
    .split(',')
    .map(origin => origin.trim())
    .filter(Boolean);
const allowedMethods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'];
const allowedHeaders = ['Content-Type', 'Authorization'];

const app = express();
require('./services/communicationWorker').start();

app.set('trust proxy', 1);
app.use(helmet());
app.use((req, res, next) => {
    const origin = req.headers.origin;
    console.log('CORS debug', req.method, req.originalUrl, 'origin=', origin, 'allowed=', allowedOrigins.includes(origin));

    if (!origin) {
        next();
        return;
    }

    if (!allowedOrigins.includes(origin)) {
        res.status(403).json({ success: false, message: 'Origin not allowed' });
        return;
    }

    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', allowedMethods.join(','));
    res.setHeader('Access-Control-Allow-Headers', allowedHeaders.join(','));
    res.setHeader('Access-Control-Allow-Credentials', 'false');
    res.setHeader('Vary', 'Origin');

    if (req.method === 'OPTIONS') {
        res.status(204).end();
        return;
    }

    next();
});
app.use(express.json({ limit: '12mb' }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/forgot-password', authLimiter);
app.use('/api/auth/reset-password', authLimiter);

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/risks', riskRoutes);
app.use('/api/treatments', treatmentRoutes);
app.use('/api/audit-logs', auditRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api', communicationRoutes);
app.use('/api', centerRoutes);
app.use('/api/workflows', workflowRoutes);
app.use('/api/executive-analytics', executiveAnalyticsRoutes);
app.use('/api/actions', actionRoutes);

app.get('/', (req, res) => {
    res.send('NCA Risk Register API is running');
});

// Test PostgreSQL connection
app.get('/api/test-db', async (req, res) => {
    try {
        const result = await pool.query(`
    SELECT
        id,
        staff_id,
        full_name,
        email,
        role,
        directorate,
        status,
        created_at,
        last_login
    FROM users
`);
        res.json({
            success: true,
            users: result.rows
        });
    } catch (error) {
        console.error(error);

        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.get('/api/protected', authMiddleware, (req, res) => {

    res.json({
        success: true,
        message: 'Welcome to the protected Risk Register Dashboard!',
        user: req.user
    });

});

app.post('/test-post', (req, res) => {
    res.json({
        success: true,
        message: 'POST route works'
    });
});

app.use('/api', (req,res) => res.status(404).json({success:false,message:`API endpoint not found: ${req.method} ${req.originalUrl}`}));
app.use((error,req,res,next)=>{console.error(error);if(res.headersSent)return next(error);res.status(500).json({success:false,message:'An unexpected server error occurred.'});});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => { console.log(`Server running on port ${PORT}`); });
