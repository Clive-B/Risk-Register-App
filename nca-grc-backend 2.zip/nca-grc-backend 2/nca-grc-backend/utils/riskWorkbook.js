const XLSX = require('xlsx');

const MAX_WORKBOOK_BYTES = 8 * 1024 * 1024;
const MAX_DATA_ROWS = 10000;
const ALLOWED_EXTENSIONS = new Set(['.xlsx', '.xls']);

const FIELD_ALIASES = {
    risk_id: ['risk id', 'risk identifier', 'risk reference', 'risk reference number', 'risk no', 'risk number', 'reference no', 'reference number', 'ref no', 's/n', 's no', 'sn', 'serial no', 'serial number', 'no'],
    risk_title: ['risk title', 'risk name', 'identified risk', 'risk'],
    risk_description: ['risk description', 'risk statement', 'risk event', 'description', 'risk event cause and consequence'],
    risk_category: ['risk category', 'category', 'risk type'],
    directorate: ['directorate', 'division', 'department', 'directorate division'],
    business_unit: ['business unit', 'unit', 'centre', 'center', 'section'],
    programme_project: ['programme project', 'program project', 'programme/project', 'program/project', 'project programme', 'project/programme'],
    risk_owner: ['risk owner', 'owner'],
    date_identified: ['date identified', 'identification date', 'date risk identified', 'risk identification date'],
    likelihood: ['likelihood', 'inherent likelihood', 'initial likelihood', 'likelihood rating'],
    impact: ['impact', 'inherent impact', 'initial impact', 'impact rating'],
    inherent_risk_score: ['inherent risk score', 'inherent score', 'initial risk score', 'inherent rating', 'initial rating'],
    risk_level: ['risk level', 'inherent risk level', 'inherent risk rating', 'initial risk level'],
    existing_controls: ['existing controls', 'existing control', 'controls', 'control measures', 'existing mitigation controls'],
    control_effectiveness: ['control effectiveness', 'controls effectiveness', 'effectiveness of controls', 'control effectiveness rating'],
    risk_treatment: ['risk treatment', 'risk response', 'treatment option', 'response strategy', 'risk treatment option'],
    initial_mitigation_plan: ['initial mitigation plan', 'mitigation plan', 'further action', 'further actions', 'additional controls', 'action plan'],
    responsible_officer: ['responsible officer', 'action owner', 'responsible person', 'responsibility'],
    target_completion_date: ['target completion date', 'completion date', 'target date', 'due date', 'action due date'],
    current_impact: ['current impact', 'current impact rating'],
    current_likelihood: ['current likelihood', 'current likelihood rating'],
    current_risk_score: ['current risk score', 'current score', 'current rating'],
    treatment_status: ['treatment status', 'action status', 'mitigation status'],
    progress_notes: ['progress notes', 'progress update', 'progress', 'comments remarks', 'remarks'],
    next_review_date: ['next review date', 'review date', 'date of next review'],
    residual_impact: ['residual impact', 'residual impact rating'],
    residual_likelihood: ['residual likelihood', 'residual likelihood rating'],
    residual_score: ['residual score', 'residual risk score', 'residual rating'],
    closure_date: ['closure date', 'date closed', 'closed date'],
    closure_comments: ['closure comments', 'closure comment', 'closure remarks'],
    status: ['status', 'risk status'],
    workflow_status: ['workflow status', 'approval status', 'workflow state']
};

const REQUIRED_FIELDS = [
    'risk_title',
    'risk_description',
    'risk_category',
    'directorate',
    'risk_owner',
    'likelihood',
    'impact',
    'existing_controls',
    'control_effectiveness',
    'risk_treatment',
    'initial_mitigation_plan',
    'responsible_officer',
    'target_completion_date'
];

function normalizeHeader(value) {
    return String(value ?? '')
        .replace(/[\r\n]+/g, ' ')
        .replace(/&/g, ' and ')
        .replace(/[^a-zA-Z0-9]+/g, ' ')
        .trim()
        .toLowerCase()
        .replace(/\s+/g, ' ')
        .replace(/^\d+\s+/, '');
}

const HEADER_LOOKUP = Object.entries(FIELD_ALIASES).reduce((lookup, [field, aliases]) => {
    aliases.forEach(alias => lookup.set(normalizeHeader(alias), field));
    lookup.set(normalizeHeader(field), field);
    return lookup;
}, new Map());

function getExtension(fileName) {
    const match = String(fileName || '').toLowerCase().match(/\.[^.]+$/);
    return match ? match[0] : '';
}

function decodeWorkbook(fileName, fileData) {
    if (!fileName || String(fileName).length > 255) throw new Error('The Excel file name is invalid.');
    const extension = getExtension(fileName);
    if (!ALLOWED_EXTENSIONS.has(extension)) {
        throw new Error('Only .xlsx and .xls files are allowed.');
    }

    const encoded = String(fileData || '').replace(/^data:[^;]+;base64,/, '').replace(/\s/g, '');
    if (!encoded || !/^[A-Za-z0-9+/]+={0,2}$/.test(encoded)) {
        throw new Error('The uploaded workbook data is invalid.');
    }

    const buffer = Buffer.from(encoded, 'base64');
    if (!buffer.length || buffer.length > MAX_WORKBOOK_BYTES) {
        throw new Error(`The workbook must be smaller than ${MAX_WORKBOOK_BYTES / 1024 / 1024} MB.`);
    }

    const isZip = buffer.length >= 4 && buffer[0] === 0x50 && buffer[1] === 0x4b;
    const isCompound = buffer.length >= 8
        && buffer.subarray(0, 8).equals(Buffer.from([0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]));
    if ((extension === '.xlsx' && !isZip) || (extension === '.xls' && !isCompound)) {
        throw new Error('The file contents do not match the selected Excel file type.');
    }

    return buffer;
}

function cellIsPopulated(value) {
    return value !== null && value !== undefined && String(value).trim() !== '';
}

function detectRegisterSheet(workbook) {
    let best = null;

    workbook.SheetNames.forEach(sheetName => {
        const worksheet = workbook.Sheets[sheetName];
        const matrix = XLSX.utils.sheet_to_json(worksheet, {
            header: 1,
            raw: true,
            defval: null,
            blankrows: true
        });

        matrix.forEach((row, rowIndex) => {
            const mappedFields = row.map(value => HEADER_LOOKUP.get(normalizeHeader(value)) || null);
            const uniqueFields = new Set(mappedFields.filter(Boolean));
            const requiredMatches = REQUIRED_FIELDS.filter(field => uniqueFields.has(field)).length;
            const anchorMatches = ['risk_title', 'risk_description', 'directorate', 'likelihood', 'impact']
                .filter(field => uniqueFields.has(field)).length;
            const score = (requiredMatches * 10) + uniqueFields.size;

            if (anchorMatches >= 3 && (!best || score > best.score)) {
                best = { sheetName, matrix, headerRowIndex: rowIndex, mappedFields, score };
            }
        });
    });

    if (!best) {
        throw new Error('The NCA Risk Register header row could not be detected.');
    }

    return best;
}

function displayValue(value) {
    if (value instanceof Date) return value.toISOString().slice(0, 10);
    return value === null || value === undefined ? '' : String(value);
}

function excelDate(value) {
    if (!cellIsPopulated(value)) return null;
    if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString().slice(0, 10);
    if (typeof value === 'number') {
        const parsed = XLSX.SSF.parse_date_code(value);
        if (parsed) return `${parsed.y}-${String(parsed.m).padStart(2, '0')}-${String(parsed.d).padStart(2, '0')}`;
    }
    const text = String(value).trim();
    const date = new Date(text);
    return Number.isNaN(date.getTime()) ? text : date.toISOString().slice(0, 10);
}

function normalizeCellValue(field, value) {
    if (!cellIsPopulated(value)) return null;
    if (['date_identified', 'target_completion_date', 'next_review_date', 'closure_date'].includes(field)) {
        return excelDate(value);
    }
    if (['likelihood', 'impact', 'inherent_risk_score', 'current_impact', 'current_likelihood', 'current_risk_score', 'residual_impact', 'residual_likelihood', 'residual_score'].includes(field)) {
        return Number(value);
    }
    return String(value).trim();
}

function parseRiskWorkbook(fileName, fileData) {
    const buffer = decodeWorkbook(fileName, fileData);
    let workbook;
    try {
        workbook = XLSX.read(buffer, { type: 'buffer', cellDates: true, cellFormula: true });
    } catch (_) {
        throw new Error('The Excel workbook is corrupt, encrypted, or cannot be read.');
    }

    const detected = detectRegisterSheet(workbook);
    const headers = detected.matrix[detected.headerRowIndex].map(displayValue);
    const nonEmptyHeaderIndexes = headers.reduce((indexes, header, index) => {
        if (cellIsPopulated(header)) indexes.push(index);
        return indexes;
    }, []);
    const unmappedHeaders = nonEmptyHeaderIndexes
        .filter(index => !detected.mappedFields[index])
        .map(index => headers[index]);
    const duplicateFields = detected.mappedFields.filter((field, index, fields) => field && fields.indexOf(field) !== index);
    const missingHeaders = REQUIRED_FIELDS.filter(field => !detected.mappedFields.includes(field));

    if (unmappedHeaders.length) {
        throw new Error(`Unsupported template column(s): ${unmappedHeaders.join(', ')}.`);
    }
    if (duplicateFields.length) {
        throw new Error(`The template contains duplicate mapped column(s): ${[...new Set(duplicateFields)].join(', ')}.`);
    }
    if (missingHeaders.length) {
        throw new Error(`The template is missing required column(s): ${missingHeaders.map(field => field.replaceAll('_', ' ')).join(', ')}.`);
    }

    const seenRiskIds = new Set();
    const rows = detected.matrix.slice(detected.headerRowIndex + 1).reduce((items, row, offset) => {
        if (!nonEmptyHeaderIndexes.some(index => cellIsPopulated(row[index]))) return items;

        const mappedData = {};
        const values = {};
        nonEmptyHeaderIndexes.forEach(index => {
            const header = headers[index];
            const field = detected.mappedFields[index];
            values[header] = displayValue(row[index]);
            mappedData[field] = normalizeCellValue(field, row[index]);
        });

        const excelRow = detected.headerRowIndex + offset + 2;
        const errors = [];
        if (mappedData.risk_id) {
            const key = String(mappedData.risk_id).toLowerCase();
            if (seenRiskIds.has(key)) errors.push('Risk ID is duplicated within the workbook.');
            seenRiskIds.add(key);
        }
        items.push({ excel_row: excelRow, values, data: mappedData, errors });
        return items;
    }, []);

    if (!rows.length) throw new Error('No populated risk data rows were found below the header row.');
    if (rows.length > MAX_DATA_ROWS) throw new Error(`A maximum of ${MAX_DATA_ROWS} populated risk rows can be imported at once.`);

    return {
        file_name: fileName,
        sheet_name: detected.sheetName,
        header_row: detected.headerRowIndex + 1,
        headers: nonEmptyHeaderIndexes.map(index => headers[index]),
        rows
    };
}

module.exports = {
    MAX_WORKBOOK_BYTES,
    REQUIRED_FIELDS,
    parseRiskWorkbook
};
