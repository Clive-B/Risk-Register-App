(() => {
    const app = window.NCAGRC;
    const user = app.getUser();
    const sidebar = document.querySelector(".sidebar");

    if (!sidebar || !user) return;

    if (!document.querySelector('link[data-sidebar-styles]')) {
        const stylesheet = document.createElement('link');
        stylesheet.rel = 'stylesheet';
        stylesheet.href = app.resolvePath('css/sidebar.css');
        stylesheet.dataset.sidebarStyles = 'true';
        document.head.appendChild(stylesheet);
    }

    const currentPage = app.getPageKey();
    const items = app.sidebars[user.role] || [];

    if (['communication','myApprovals','approvalDetails','executiveAnalytics','boardDashboard'].includes(currentPage) && !document.querySelector('link[data-communication-sidebar-styles]')) {
        const theme = document.createElement('link');
        theme.rel = 'stylesheet';
        theme.href = app.resolvePath('css/communication-sidebar.css');
        theme.dataset.communicationSidebarStyles = 'true';
        document.head.appendChild(theme);
    }

    sidebar.innerHTML = `
        <header class="sidebar-header">
            <div class="logo">
                <img class="brand-mark" src="${app.resolvePath("assets/images/NCA_-_Logo-04.png")}" alt="National Communications Authority logo">
                <div>
                    <h2>NCA GRC</h2>
                    <span>30 Years | 1996 - 2026</span>
                </div>
            </div>
            <img class="anniversary-mark" src="${app.resolvePath("assets/images/IMG-20260305-WA0016-removebg-preview(2)(7).png")}" alt="NCA 30 years anniversary branding">
        </header>
        <nav class="sidebar-nav" aria-label="Primary navigation">
            <ul>
                ${items.map(([label, href, key]) => `
                    <li class="${key === currentPage ? "active" : ""}">
                        <a href="${app.resolvePath(href)}">${label}</a>
                    </li>
                `).join("")}
            </ul>
        </nav>
        <footer class="sidebar-footer">
            <button id="logoutBtn" class="logout-btn" type="button">Logout</button>
        </footer>
    `;

    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'sidebar-toggle';
    toggle.setAttribute('aria-label', 'Open navigation menu');
    toggle.setAttribute('aria-controls', 'ncaSidebar');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.textContent = '☰';
    sidebar.id = 'ncaSidebar';

    const overlay = document.createElement('div');
    overlay.className = 'sidebar-overlay';
    overlay.setAttribute('aria-hidden', 'true');
    document.body.append(toggle, overlay);

    function setDrawer(open) {
        sidebar.classList.toggle('is-open', open);
        overlay.classList.toggle('is-visible', open);
        document.body.classList.toggle('sidebar-drawer-open', open);
        toggle.setAttribute('aria-expanded', String(open));
        toggle.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
        toggle.textContent = open ? '×' : '☰';
    }

    toggle.addEventListener('click', () => setDrawer(!sidebar.classList.contains('is-open')));
    overlay.addEventListener('click', () => setDrawer(false));
    sidebar.querySelector('.sidebar-nav').addEventListener('click', event => {
        if (event.target.closest('a') && window.innerWidth < 992) setDrawer(false);
    });
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') setDrawer(false);
    });
    window.addEventListener('resize', () => {
        if (window.innerWidth >= 992) setDrawer(false);
    });

    const logoutBtn = document.getElementById("logoutBtn");

    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => app.logout(app.resolvePath("index.html")));
    }
})();
