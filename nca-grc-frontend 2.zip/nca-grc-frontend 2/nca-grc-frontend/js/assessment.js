const API_URL = "http://localhost:3000/api";

const token = localStorage.getItem("token");
const currentUser = JSON.parse(localStorage.getItem("user"));

if (!token) {
    window.location.href = "../index.html";
}

if (window.NCAGRC_ACCESS_DENIED) {
    throw new Error("Access denied.");
}

const state = {
    risks: [],
    filteredRisks: [],
    isLoading: false
};

const elements = {
    acceptedRisks: document.getElementById("acceptedRisks"),
    assessedRisks: document.getElementById("assessedRisks"),
    assessmentTable: document.getElementById("assessmentTable"),
    averageScore: document.getElementById("averageScore"),
    directorateFilter: document.getElementById("directorateFilter"),
    emptyState: document.getElementById("emptyState"),
    escalatedRisks: document.getElementById("escalatedRisks"),
    heatMap: document.getElementById("heatMap"),
    heatMapTotal: document.getElementById("heatMapTotal"),
    impactMatrix: document.getElementById("impactMatrix"),
    levelFilter: document.getElementById("levelFilter"),
    likelihoodMatrix: document.getElementById("likelihoodMatrix"),
    loadingState: document.getElementById("loadingState"),
    searchInput: document.getElementById("searchInput"),
    toastContainer: document.getElementById("toastContainer"),
    userInfo: document.getElementById("userInfo")
};

const likelihoodLabels = {
    1: "Rare",
    2: "Unlikely",
    3: "Possible",
    4: "Likely",
    5: "Almost Certain"
};

const impactLabels = {
    1: "Insignificant",
    2: "Minor",
    3: "Moderate",
    4: "Major",
    5: "Severe"
};

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastContainer.appendChild(toast);

    window.setTimeout(() => {
        toast.classList.add("hide");
        toast.addEventListener("transitionend", () => toast.remove(), { once: true });
    }, 3200);
}

async function apiRequest(path) {
    const response = await fetch(`${API_URL}${path}`, {
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        }
    });

    const data = await response.json().catch(() => ({
        success: false,
        message: "Unexpected server response."
    }));

    if (!response.ok || !data.success) {
        throw new Error(data.message || "Request failed.");
    }

    return data;
}

function setLoggedInUser() {
    if (!currentUser) return;

    elements.userInfo.innerHTML = `
        <strong>${escapeHtml(currentUser.full_name)}</strong>
        <br>
        <small>${escapeHtml(currentUser.role)}</small>
    `;

    if (!["System Administrator","Risk Committee Chairman"].includes(currentUser.role)) {
        elements.directorateFilter.value = currentUser.directorate || "";
        elements.directorateFilter.disabled = true;
    }
}

function setLoading(isLoading) {
    state.isLoading = isLoading;
    elements.loadingState.style.display = isLoading ? "block" : "none";
}

function buildQueryString() {
    const params = new URLSearchParams();
    const search = elements.searchInput.value.trim();
    const directorate = elements.directorateFilter.value;
    const riskLevel = elements.levelFilter.value;

    if (search) params.set("search", search);
    if (directorate) params.set("directorate", directorate);
    if (riskLevel) params.set("risk_level", riskLevel);

    const query = params.toString();
    return query ? `?${query}` : "";
}

async function loadAssessments() {
    try {
        setLoading(true);
        const data = await apiRequest(`/risks${buildQueryString()}`);
        state.risks = data.risks || [];
        state.filteredRisks = state.risks;
        renderAssessment();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to load assessments.", "error");
    } finally {
        setLoading(false);
        renderAssessment();
    }
}

function renderAssessment() {
    updateStats();
    renderMatrices();
    renderHeatMap();
    renderTable();
}

function updateStats() {
    const total = state.filteredRisks.length;
    const scoreTotal = state.filteredRisks.reduce((sum, risk) => sum + Number(risk.inherent_risk_score || 0), 0);
    const accepted = state.filteredRisks.filter(isAcceptedRisk).length;
    const escalated = state.filteredRisks.filter(shouldEscalateRisk).length;

    elements.assessedRisks.textContent = total;
    elements.averageScore.textContent = total ? (scoreTotal / total).toFixed(1) : "0";
    elements.acceptedRisks.textContent = accepted;
    elements.escalatedRisks.textContent = escalated;
    elements.heatMapTotal.textContent = `${total} risks`;
}

function renderMatrices() {
    elements.likelihoodMatrix.innerHTML = "";
    elements.impactMatrix.innerHTML = "";

    Object.entries(likelihoodLabels).forEach(([score, label]) => {
        elements.likelihoodMatrix.appendChild(createMatrixItem(score, label, countByField("likelihood", score)));
    });

    Object.entries(impactLabels).forEach(([score, label]) => {
        elements.impactMatrix.appendChild(createMatrixItem(score, label, countByField("impact", score)));
    });
}

function createMatrixItem(score, label, count) {
    const item = document.createElement("div");
    item.className = "matrix-item";
    item.innerHTML = `
        <span class="matrix-score">${escapeHtml(score)}</span>
        <div>
            <strong>${escapeHtml(label)}</strong>
            <small>${count} risks</small>
        </div>
    `;
    return item;
}

function countByField(field, score) {
    return state.filteredRisks.filter(risk => Number(risk[field]) === Number(score)).length;
}

function renderHeatMap() {
    elements.heatMap.innerHTML = "";

    for (let impact = 5; impact >= 1; impact -= 1) {
        for (let likelihood = 1; likelihood <= 5; likelihood += 1) {
            const score = likelihood * impact;
            const count = state.filteredRisks.filter(risk =>
                Number(risk.likelihood) === likelihood && Number(risk.impact) === impact
            ).length;

            const cell = document.createElement("div");
            cell.className = `heat-cell ${getLevelClass(calculateRiskLevel(score))}`;
            cell.innerHTML = `
                <strong>${score}</strong>
                <span>L${likelihood} x I${impact}</span>
                <small>${count}</small>
            `;
            elements.heatMap.appendChild(cell);
        }
    }
}

function renderTable() {
    elements.assessmentTable.innerHTML = "";

    state.filteredRisks.forEach(risk => {
        const row = document.createElement("tr");
        const decision = getDecision(risk);

        row.innerHTML = `
            <td><strong>${escapeHtml(risk.risk_id)}</strong></td>
            <td>
                <strong>${escapeHtml(risk.risk_title)}</strong>
                <br>
                <small>${escapeHtml(risk.risk_category)}</small>
            </td>
            <td>${escapeHtml(risk.directorate)}</td>
            <td>${escapeHtml(risk.likelihood)} - ${escapeHtml(likelihoodLabels[risk.likelihood])}</td>
            <td>${escapeHtml(risk.impact)} - ${escapeHtml(impactLabels[risk.impact])}</td>
            <td><span class="score-pill">${escapeHtml(risk.inherent_risk_score)}</span></td>
            <td><span class="score-pill muted">${escapeHtml(risk.residual_risk_score)}</span></td>
            <td>
                <span class="level-badge ${getLevelClass(risk.risk_level)}">
                    ${escapeHtml(risk.risk_level)}
                </span>
            </td>
            <td>
                <span class="decision-badge ${decision.className}">
                    ${escapeHtml(decision.label)}
                </span>
            </td>
        `;

        elements.assessmentTable.appendChild(row);
    });

    elements.emptyState.style.display = !state.isLoading && state.filteredRisks.length === 0 ? "block" : "none";
}

function calculateRiskLevel(score) {
    if (score >= 20) return "Critical";
    if (score >= 12) return "High";
    if (score >= 6) return "Medium";
    return "Low";
}

function getLevelClass(level) {
    return String(level || "").toLowerCase();
}

function isAcceptedRisk(risk) {
    return risk.status === "Accepted" || risk.risk_treatment === "Accept";
}

function shouldEscalateRisk(risk) {
    return ["High", "Critical"].includes(risk.risk_level) && risk.status !== "Closed";
}

function getDecision(risk) {
    if (isAcceptedRisk(risk)) {
        return { label: "Accepted", className: "accepted" };
    }

    if (shouldEscalateRisk(risk)) {
        return { label: "Escalate", className: "escalate" };
    }

    return { label: "Monitor", className: "monitor" };
}

function bindEvents() {
    document.getElementById("logoutBtn").addEventListener("click", () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        window.location.href = "../index.html";
    });

    [
        elements.searchInput,
        elements.directorateFilter,
        elements.levelFilter
    ].forEach(field => {
        field.addEventListener("input", loadAssessments);
        field.addEventListener("change", loadAssessments);
    });
}

setLoggedInUser();
bindEvents();
loadAssessments();
