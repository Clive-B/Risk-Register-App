const app = window.NCAGRC;
const API_URL = app.API_URL;
const token = app.getToken();
const currentUser = app.getUser();

if (window.NCAGRC_ACCESS_DENIED) {
    throw new Error("Access denied.");
}

const DIRECTORATES = [
    "RIPS",
    "Legal",
    "Regulatory Administration",
    "Consumer Affairs",
    "Corporate Affairs",
    "Finance",
    "Engineering",
    "Information Technology",
    "Procurement and Protocol",
    "Internal Audit",
    "Human Resource",
    "ROD",
    "Administration",
    "Cybersecurity",
    "International Affairs"
];

const CATEGORIES = [
    "Strategic",
    "Operational",
    "Financial",
    "Compliance",
    "ICT",
    "Legal",
    "Cybersecurity",
    "Reputational",
    "Health & Safety"
];

const RESPONSES = ["Avoid", "Reduce", "Transfer", "Share", "Accept", "Fallback"];
const CONTROL_EFFECTIVENESS = ["Effective", "Partially Effective", "Ineffective"];
const TREATMENT_STATUSES = ["Not Started", "In Progress", "Completed", "Deferred"];
const SCORE_LABELS = ["1", "2", "3", "4", "5"];

const params = new URLSearchParams(window.location.search);
const editingRiskId = params.get("id");
let loadedRisk = null;

const elements = {
    pageTitle: document.getElementById("pageTitle"),
    userInfo: document.getElementById("userInfo"),
    toastContainer: document.getElementById("toastContainer"),
    workflowBadge: document.getElementById("workflowBadge"),
    riskRatingBadge: document.getElementById("riskRatingBadge"),
    residualBadge: document.getElementById("residualBadge"),
    monitoringSection: document.getElementById("monitoringSection"),
    closureSection: document.getElementById("closureSection"),
    attachmentList: document.getElementById("attachmentList"),
    saveDraftBtn: document.getElementById("saveDraftBtn"),
    submitBtn: document.getElementById("submitBtn"),
    saveMonitoringBtn: document.getElementById("saveMonitoringBtn"),
    closeRiskBtn: document.getElementById("closeRiskBtn"),
    cancelBtn: document.getElementById("cancelBtn")
};

const fields = [
    "risk_id",
    "date_identified",
    "risk_title",
    "risk_description",
    "directorate",
    "business_unit",
    "programme_project",
    "risk_category",
    "risk_owner",
    "impact",
    "likelihood",
    "inherent_risk_score",
    "risk_level",
    "existing_controls",
    "control_effectiveness",
    "risk_treatment",
    "initial_mitigation_plan",
    "responsible_officer",
    "target_completion_date",
    "current_impact",
    "current_likelihood",
    "current_risk_score",
    "treatment_status",
    "review_date",
    "residual_impact",
    "residual_likelihood",
    "residual_score",
    "progress_notes",
    "attachments",
    "closure_date",
    "closure_comments"
].reduce((map, id) => ({ ...map, [id]: document.getElementById(id) }), {});

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function setUserCard() {
    elements.userInfo.innerHTML = `
        <strong>${escapeHtml(currentUser.full_name)}</strong>
        <br>
        <small>${escapeHtml(currentUser.role)}</small>
    `;
}

function fillSelect(select, options, placeholder = "Select") {
    select.innerHTML = `<option value="">${placeholder}</option>${options.map(option => `<option>${escapeHtml(option)}</option>`).join("")}`;
}

function fillScoreSelect(select, placeholder) {
    select.innerHTML = `<option value="">${placeholder}</option>${SCORE_LABELS.map(value => `<option value="${value}">${value}</option>`).join("")}`;
}

function setupOptions() {
    fillSelect(fields.directorate, DIRECTORATES, "Select Division");
    fillSelect(fields.risk_category, CATEGORIES, "Select Category");
    fillSelect(fields.control_effectiveness, CONTROL_EFFECTIVENESS, "Select Effectiveness");
    fillSelect(fields.risk_treatment, RESPONSES, "Select Response");
    fillSelect(fields.treatment_status, TREATMENT_STATUSES, "Select Treatment Status");

    [
        fields.impact,
        fields.likelihood,
        fields.current_impact,
        fields.current_likelihood,
        fields.residual_impact,
        fields.residual_likelihood
    ].forEach(select => fillScoreSelect(select, "Select 1-5"));
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastContainer.appendChild(toast);
    window.setTimeout(() => {
        toast.classList.add("hide");
        toast.addEventListener("transitionend", () => toast.remove(), { once: true });
    }, 3200);
}

async function apiRequest(path, options = {}) {
    const response = await fetch(`${API_URL}${path}`, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            ...(options.headers || {})
        }
    });
    const data = await response.json().catch(() => ({ success: false, message: "Unexpected server response." }));
    if (!response.ok || !data.success) throw new Error(data.message || "Request failed.");
    return data;
}

function formatDate(value) {
    return value ? String(value).slice(0, 10) : "";
}

function calculateLevel(score) {
    if (score >= 20) return "Critical";
    if (score >= 12) return "High";
    if (score >= 6) return "Medium";
    return "Low";
}

function setBadge(badge, label, level) {
    badge.className = `level-badge ${String(level).toLowerCase()}`;
    badge.textContent = label;
}

function updateInherentScore() {
    const score = (Number(fields.impact.value) || 0) * (Number(fields.likelihood.value) || 0);
    const level = calculateLevel(score || 1);
    fields.inherent_risk_score.value = score || 0;
    fields.risk_level.value = level;
    setBadge(elements.riskRatingBadge, level, level);
}

function updateMonitoringScores() {
    const currentScore = (Number(fields.current_impact.value) || 0) * (Number(fields.current_likelihood.value) || 0);
    const residualScore = (Number(fields.residual_impact.value) || 0) * (Number(fields.residual_likelihood.value) || 0);
    const residualLevel = calculateLevel(residualScore || 1);
    fields.current_risk_score.value = currentScore || 0;
    fields.residual_score.value = residualScore || 0;
    setBadge(elements.residualBadge, `Residual ${residualScore || 0}`, residualLevel);
}

function applyRoleDefaults() {
    const today = new Date().toISOString().slice(0, 10);
    fields.date_identified.value = today;
    fields.closure_date.value = today;
    fields.review_date.value = today;

    if (currentUser.role === "Risk Focal Person") {
        fields.directorate.value = currentUser.directorate || "";
        fields.directorate.disabled = true;
        fields.risk_owner.value = currentUser.full_name || "";
        fields.risk_owner.disabled = true;
    }
}

function setWorkflowBadge(status) {
    const workflowStatus = status || "Draft";
    elements.workflowBadge.className = `status ${workflowStatus.toLowerCase().replaceAll(" ", "-")}`;
    elements.workflowBadge.textContent = workflowStatus;
}

function applyLifecycleMode(risk) {
    const approved = ["Accepted","Treatment In Progress","Monitoring"].includes(risk?.workflow_status);
    const closed = risk?.workflow_status === "Closed" || risk?.status === "Closed";

    elements.monitoringSection.classList.toggle("hidden", !approved && !closed);
    elements.closureSection.classList.toggle("hidden", !(approved && risk?.treatment_status === "Completed") && !closed);
    elements.saveMonitoringBtn.classList.toggle("hidden", !approved);
    elements.closeRiskBtn.classList.toggle("hidden", !(approved && risk?.treatment_status === "Completed"));

    elements.saveDraftBtn.classList.toggle("hidden", approved || closed);
    elements.submitBtn.classList.toggle("hidden", approved || closed);

    if (closed) {
        document.querySelectorAll("input, select, textarea, button").forEach(control => {
            if (control.id !== "cancelBtn") control.disabled = true;
        });
    }
}

function populateRisk(risk) {
    loadedRisk = risk;
    elements.pageTitle.textContent = "Edit Risk";
    setWorkflowBadge(risk.workflow_status);

    Object.keys(fields).forEach(key => {
        if (!fields[key] || fields[key].type === "file") return;
        if (risk[key] !== undefined && risk[key] !== null) {
            fields[key].value = key.includes("date") ? formatDate(risk[key]) : risk[key];
        }
    });

    fields.review_date.value = formatDate(risk.next_review_date) || fields.review_date.value;
    fields.residual_score.value = risk.residual_score || risk.residual_risk_score || 0;
    updateInherentScore();
    updateMonitoringScores();
    applyLifecycleMode(risk);
}

function getRiskPayload(workflowStatus) {
    return {
        risk_title: fields.risk_title.value.trim(),
        risk_description: fields.risk_description.value.trim(),
        directorate: fields.directorate.value,
        business_unit: fields.business_unit.value.trim(),
        programme_project: fields.programme_project.value.trim(),
        risk_category: fields.risk_category.value,
        risk_owner: fields.risk_owner.value.trim(),
        date_identified: fields.date_identified.value,
        impact: Number(fields.impact.value),
        likelihood: Number(fields.likelihood.value),
        existing_controls: fields.existing_controls.value.trim(),
        control_effectiveness: fields.control_effectiveness.value,
        risk_treatment: fields.risk_treatment.value,
        initial_mitigation_plan: fields.initial_mitigation_plan.value.trim(),
        responsible_officer: fields.responsible_officer.value.trim(),
        target_completion_date: fields.target_completion_date.value,
        workflow_status: workflowStatus
    };
}

function validateRiskPayload(payload) {
    if (!payload.risk_title) return "Risk title is required.";
    if (!payload.risk_description) return "Risk description is required.";
    if (!DIRECTORATES.includes(payload.directorate)) return "Select a valid division.";
    if (!CATEGORIES.includes(payload.risk_category)) return "Select a valid risk category.";
    if (!payload.risk_owner) return "Risk owner is required.";
    if (!payload.impact || !payload.likelihood) return "Impact and likelihood are required.";
    if (!payload.existing_controls) return "Existing controls are required.";
    if (!CONTROL_EFFECTIVENESS.includes(payload.control_effectiveness)) return "Select a valid control effectiveness.";
    if (!RESPONSES.includes(payload.risk_treatment)) return "Select a valid risk response.";
    if (!payload.initial_mitigation_plan) return "Initial mitigation plan is required.";
    if (!payload.responsible_officer) return "Responsible officer is required.";
    if (!payload.target_completion_date) return "Target completion date is required.";
    return "";
}

function readFileAsDataUrl(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsDataURL(file);
    });
}

async function uploadAttachments(riskId) {
    const files = Array.from(fields.attachments.files || []);
    for (const file of files) {
        const dataUrl = await readFileAsDataUrl(file);
        await apiRequest(`/risks/${riskId}/attachments`, {
            method: "POST",
            body: JSON.stringify({
                file_name: file.name,
                file_type: file.type,
                file_size: file.size,
                file_data: dataUrl
            })
        });
    }
}

async function saveRisk(workflowStatus) {
    const payload = getRiskPayload(workflowStatus);
    const validationError = validateRiskPayload(payload);
    if (validationError) {
        showToast(validationError, "error");
        return;
    }

    const method = editingRiskId ? "PUT" : "POST";
    const path = editingRiskId ? `/risks/${editingRiskId}` : "/risks";

    try {
        const data = await apiRequest(path, {
            method,
            body: JSON.stringify(payload)
        });
        await uploadAttachments(data.risk.id);
        showToast(workflowStatus === "Submitted" ? "Risk submitted for approval." : "Risk draft saved.");
        window.location.href = "risks.html";
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to save risk.", "error");
    }
}

async function saveMonitoringUpdate() {
    const payload = {
        current_impact: Number(fields.current_impact.value) || null,
        current_likelihood: Number(fields.current_likelihood.value) || null,
        progress_notes: fields.progress_notes.value.trim(),
        treatment_status: fields.treatment_status.value,
        review_date: fields.review_date.value,
        residual_impact: Number(fields.residual_impact.value) || null,
        residual_likelihood: Number(fields.residual_likelihood.value) || null
    };

    if (!TREATMENT_STATUSES.includes(payload.treatment_status)) {
        showToast("Select a valid treatment status.", "error");
        return;
    }

    try {
        const data = await apiRequest(`/risks/${editingRiskId}/treatment-updates`, {
            method: "POST",
            body: JSON.stringify(payload)
        });
        showToast("Monitoring update saved.");
        populateRisk(data.risk);
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to save monitoring update.", "error");
    }
}

async function closeRisk() {
    if (!fields.closure_comments.value.trim()) {
        showToast("Closure comments are required.", "error");
        return;
    }

    try {
        await apiRequest(`/risks/${editingRiskId}/close`, {
            method: "PATCH",
            body: JSON.stringify({
                closure_date: fields.closure_date.value,
                closure_comments: fields.closure_comments.value.trim()
            })
        });
        showToast("Risk closed successfully.");
        window.location.href = "risks.html";
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to close risk.", "error");
    }
}

async function loadRisk() {
    if (!editingRiskId) {
        setWorkflowBadge("Draft");
        return;
    }

    const data = await apiRequest("/risks");
    const risk = (data.risks || []).find(item => Number(item.id) === Number(editingRiskId));
    if (!risk) {
        showToast("Risk not found or not accessible.", "error");
        return;
    }
    populateRisk(risk);
}

function renderAttachmentSelection() {
    const files = Array.from(fields.attachments.files || []);
    elements.attachmentList.innerHTML = files.length
        ? files.map(file => `<div>${escapeHtml(file.name)} <small>${Math.ceil(file.size / 1024)} KB</small></div>`).join("")
        : "No attachments selected.";
}

function bindEvents() {
    [fields.impact, fields.likelihood].forEach(field => field.addEventListener("change", updateInherentScore));
    [fields.current_impact, fields.current_likelihood, fields.residual_impact, fields.residual_likelihood].forEach(field => {
        field.addEventListener("change", updateMonitoringScores);
    });
    fields.attachments.addEventListener("change", renderAttachmentSelection);
    fields.treatment_status.addEventListener("change", () => {
        if (loadedRisk) {
            loadedRisk.treatment_status = fields.treatment_status.value;
            applyLifecycleMode(loadedRisk);
        }
    });

    elements.saveDraftBtn.addEventListener("click", () => saveRisk("Draft"));
    elements.submitBtn.addEventListener("click", () => saveRisk("Submitted"));
    elements.saveMonitoringBtn.addEventListener("click", saveMonitoringUpdate);
    elements.closeRiskBtn.addEventListener("click", closeRisk);
    elements.cancelBtn.addEventListener("click", () => {
        window.location.href = "risks.html";
    });
}

setUserCard();
setupOptions();
applyRoleDefaults();
bindEvents();
loadRisk().catch(error => {
    console.error(error);
    showToast(error.message || "Unable to load risk.", "error");
});
