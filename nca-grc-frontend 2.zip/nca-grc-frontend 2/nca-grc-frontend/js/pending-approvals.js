const app = window.NCAGRC;
const API_URL = app.API_URL;
const token = app.getToken();
const currentUser = app.getUser();

if (window.NCAGRC_ACCESS_DENIED) {
    throw new Error("Access denied.");
}

const state = {
    risks: [],
    selectedRisk: null
};

const elements = {
    userInfo: document.getElementById("userInfo"),
    toastContainer: document.getElementById("toastContainer"),
    loadingState: document.getElementById("loadingState"),
    emptyState: document.getElementById("emptyState"),
    table: document.getElementById("approvalTable"),
    searchInput: document.getElementById("searchInput"),
    levelFilter: document.getElementById("levelFilter"),
    pendingCount: document.getElementById("pendingCount"),
    highCount: document.getElementById("highCount"),
    criticalCount: document.getElementById("criticalCount"),
    directorateCount: document.getElementById("directorateCount"),
    modal: document.getElementById("reviewModal"),
    closeModal: document.getElementById("closeModal"),
    cancelReview: document.getElementById("cancelReview"),
    reviewTitle: document.getElementById("reviewTitle"),
    reviewSummary: document.getElementById("reviewSummary"),
    reviewComment: document.getElementById("reviewComment"),
    approveRisk: document.getElementById("approveRisk"),
    returnRisk: document.getElementById("returnRisk"),
    rejectRisk: document.getElementById("rejectRisk")
};
elements.recommendRisk = document.getElementById("recommendRisk");

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastContainer.appendChild(toast);
    window.setTimeout(() => {
        toast.classList.add("hide");
        toast.addEventListener("transitionend", () => toast.remove(), { once: true });
    }, 3200);
}

async function apiRequest(path, options = {}) {
    const response = await fetch(`${API_URL}${path}`, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            ...(options.headers || {})
        }
    });
    const data = await response.json().catch(() => ({ success: false, message: "Unexpected server response." }));
    if (!response.ok || !data.success) throw new Error(data.message || "Request failed.");
    return data;
}

function formatDate(value) {
    if (!value) return "";
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    }).format(new Date(value));
}

function getLevelClass(level) {
    return String(level || "").toLowerCase();
}

function setUserCard() {
    elements.userInfo.innerHTML = `
        <strong>${escapeHtml(currentUser.full_name)}</strong>
        <br>
        <small>${escapeHtml(currentUser.role)}</small>
    `;
}

function getFilteredRisks() {
    const search = elements.searchInput.value.trim().toLowerCase();
    const level = elements.levelFilter.value;

    return state.risks.filter(risk => {
        const matchesSearch = !search
            || String(risk.risk_id).toLowerCase().includes(search)
            || String(risk.risk_title).toLowerCase().includes(search)
            || String(risk.risk_owner).toLowerCase().includes(search);
        const matchesLevel = !level || risk.risk_level === level;
        return matchesSearch && matchesLevel;
    });
}

function updateStats() {
    elements.pendingCount.textContent = state.risks.length;
    elements.highCount.textContent = state.risks.filter(risk => risk.risk_level === "High").length;
    elements.criticalCount.textContent = state.risks.filter(risk => risk.risk_level === "Critical").length;
    elements.directorateCount.textContent = new Set(state.risks.map(risk => risk.directorate)).size;
}

function renderRisks() {
    const risks = getFilteredRisks();
    elements.table.innerHTML = risks.map(risk => `
        <tr>
            <td><strong>${escapeHtml(risk.risk_id)}</strong></td>
            <td>
                <strong>${escapeHtml(risk.risk_title)}</strong>
                <br>
                <small>${escapeHtml(risk.risk_category)}</small>
            </td>
            <td>${escapeHtml(risk.directorate)}</td>
            <td>${escapeHtml(risk.risk_owner)}</td>
            <td><span class="score-pill">${escapeHtml(risk.inherent_risk_score)}</span></td>
            <td><span class="level-badge ${getLevelClass(risk.risk_level)}">${escapeHtml(risk.risk_level)}</span></td>
            <td>${formatDate(risk.submitted_at || risk.updated_at)}</td>
            <td>
                <button class="edit-btn" type="button" data-id="${risk.id}">Review</button>
            </td>
        </tr>
    `).join("");
    elements.emptyState.style.display = risks.length ? "none" : "block";
}

async function openReviewModal(id) {
    const risk = state.risks.find(item => Number(item.id) === Number(id));
    if (!risk) return;

    if(currentUser.role==='Risk Champion'&&risk.workflow_status==='Submitted'){
        try{const started=await apiRequest(`/risks/${risk.id}/start-review`,{method:'PATCH'});Object.assign(risk,started.risk||{})}catch(error){showToast(error.message,'error');return}
    }

    state.selectedRisk = risk;
    elements.reviewTitle.textContent = `Review ${risk.risk_id}`;
    elements.reviewSummary.innerHTML = `
        <div><strong>Risk</strong>${escapeHtml(risk.risk_title)}</div>
        <div><strong>Division</strong>${escapeHtml(risk.division || risk.directorate)}</div>
        <div><strong>Rating</strong>${escapeHtml(risk.risk_level)} (${escapeHtml(risk.inherent_risk_score)})</div>
        <div><strong>Owner</strong>${escapeHtml(risk.risk_owner)}</div>
        <div><strong>Response</strong>${escapeHtml(risk.risk_treatment)}</div>
        <div><strong>Target</strong>${formatDate(risk.target_completion_date)}</div>
        <div class="full-width"><strong>Description</strong>${escapeHtml(risk.risk_description)}</div>
        <div class="full-width"><strong>Controls</strong>${escapeHtml(risk.existing_controls)}</div>
    `;
    elements.reviewComment.value = "";
    elements.modal.style.display = "flex";
    elements.modal.setAttribute("aria-hidden", "false");
    elements.reviewComment.focus();
}

function closeModal() {
    elements.modal.style.display = "none";
    elements.modal.setAttribute("aria-hidden", "true");
    state.selectedRisk = null;
}

async function submitDecision(decision) {
    if (!state.selectedRisk) return;

    try {
        const isChairman=currentUser.role === "Risk Committee Chairman";
        if(isChairman&&decision==='reject')decision='return';
        const data = await apiRequest(isChairman?`/risks/${state.selectedRisk.id}/committee-review`:`/risks/${state.selectedRisk.id}/review`, {
            method: "PATCH",
            body: JSON.stringify({
                ...(isChairman?{action:decision,comments:elements.reviewComment.value.trim(),recommendations:decision==='recommend'?elements.reviewComment.value.trim():null}:{decision,review_comments:elements.reviewComment.value.trim()})
            })
        });
        showToast(data.message || "Risk reviewed successfully.");
        closeModal();
        await loadRisks();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to review risk.", "error");
    }
}

async function loadRisks() {
    try {
        elements.loadingState.style.display = "block";
        const chairman=currentUser.role === "Risk Committee Chairman";
        if(chairman){const data=await apiRequest("/risks?workflow_status=Accepted");state.risks=(data.risks||[]).filter(r=>["High","Critical"].includes(r.risk_level))}
        else{const [submitted,reviewing]=await Promise.all([apiRequest("/risks?workflow_status=Submitted"),apiRequest("/risks?workflow_status=Under Review")]);state.risks=[...(submitted.risks||[]),...(reviewing.risks||[])]}
        updateStats();
        renderRisks();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to load approvals.", "error");
    } finally {
        elements.loadingState.style.display = "none";
    }
}

function bindEvents() {
    elements.table.addEventListener("click", event => {
        const button = event.target.closest("button[data-id]");
        if (button) openReviewModal(button.dataset.id);
    });
    elements.searchInput.addEventListener("input", renderRisks);
    elements.levelFilter.addEventListener("change", renderRisks);
    elements.closeModal.addEventListener("click", closeModal);
    elements.cancelReview.addEventListener("click", closeModal);
    elements.approveRisk.addEventListener("click", () => submitDecision("approve"));
    elements.returnRisk.addEventListener("click", () => submitDecision("return"));
    elements.rejectRisk.addEventListener("click", () => submitDecision("reject"));
    elements.recommendRisk.addEventListener("click", () => submitDecision("recommend"));
    elements.modal.addEventListener("click", event => {
        if (event.target === elements.modal) closeModal();
    });
}

setUserCard();
if(currentUser.role==="Risk Committee Chairman"){document.querySelector('.topbar h1').textContent='High & Critical Risk Reviews';document.querySelector('.topbar p').textContent='Enterprise-wide committee oversight, recommendations and executive comments';elements.approveRisk.textContent='Approve';elements.returnRisk.textContent='Return Risk';elements.rejectRisk.hidden=true}
elements.recommendRisk.hidden=currentUser.role!=="Risk Committee Chairman";
bindEvents();
loadRisks();
