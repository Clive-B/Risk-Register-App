const API_URL = "http://localhost:3000/api";

const token = localStorage.getItem("token");
const currentUser = JSON.parse(localStorage.getItem("user"));

if (!token) {
    window.location.href = "../index.html";
}

if (window.NCAGRC_ACCESS_DENIED) {
    throw new Error("Access denied.");
}

const state = {
    risks: [],
    treatmentPlans: [],
    reportRows: [],
    isLoading: false
};

const elements = {
    criticalRisks: document.getElementById("criticalRisks"),
    csvBtn: document.getElementById("csvBtn"),
    directorateFilter: document.getElementById("directorateFilter"),
    emptyState: document.getElementById("emptyState"),
    excelBtn: document.getElementById("excelBtn"),
    generatedDate: document.getElementById("generatedDate"),
    loadingState: document.getElementById("loadingState"),
    openRisks: document.getElementById("openRisks"),
    overdueActions: document.getElementById("overdueActions"),
    pdfBtn: document.getElementById("pdfBtn"),
    printBtn: document.getElementById("printBtn"),
    reportBody: document.getElementById("reportBody"),
    reportHead: document.getElementById("reportHead"),
    reportRows: document.getElementById("reportRows"),
    reportTitle: document.getElementById("reportTitle"),
    reportType: document.getElementById("reportType"),
    searchInput: document.getElementById("searchInput"),
    statusFilter: document.getElementById("statusFilter"),
    toastContainer: document.getElementById("toastContainer"),
    userInfo: document.getElementById("userInfo")
};

const reportConfig = {
    risk: {
        title: "Risk Register Report",
        statuses: ["Open", "In Progress", "Mitigated", "Accepted", "Closed"],
        columns: [
            ["risk_id", "Risk ID"],
            ["risk_title", "Risk Title"],
            ["risk_category", "Category"],
            ["directorate", "Division"],
            ["risk_owner", "Owner"],
            ["likelihood", "Likelihood"],
            ["impact", "Impact"],
            ["inherent_risk_score", "Inherent Score"],
            ["residual_risk_score", "Residual Score"],
            ["risk_level", "Level"],
            ["risk_treatment", "Treatment"],
            ["status", "Status"],
            ["created_at", "Created Date"]
        ]
    },
    treatment: {
        title: "Treatment Plan Report",
        statuses: ["Not Started", "In Progress", "Completed", "Overdue"],
        columns: [
            ["risk_code", "Risk ID"],
            ["risk_title", "Risk Title"],
            ["directorate", "Division"],
            ["plan_title", "Plan Title"],
            ["treatment_strategy", "Strategy"],
            ["action_owner", "Action Owner"],
            ["due_date", "Due Date"],
            ["progress_percent", "Completion %"],
            ["status", "Status"],
            ["evidence_status", "Evidence"]
        ]
    },
    assessment: {
        title: "Risk Assessment Report",
        statuses: ["Low", "Medium", "High", "Critical"],
        columns: [
            ["risk_id", "Risk ID"],
            ["risk_title", "Risk Title"],
            ["directorate", "Division"],
            ["likelihood_label", "Likelihood"],
            ["impact_label", "Impact"],
            ["inherent_risk_score", "Inherent Score"],
            ["residual_risk_score", "Residual Score"],
            ["risk_level", "Risk Rating"],
            ["assessment_decision", "Decision"],
            ["status", "Status"]
        ]
    }
};

const likelihoodLabels = {
    1: "1 - Rare",
    2: "2 - Unlikely",
    3: "3 - Possible",
    4: "4 - Likely",
    5: "5 - Almost Certain"
};

const impactLabels = {
    1: "1 - Insignificant",
    2: "2 - Minor",
    3: "3 - Moderate",
    4: "4 - Major",
    5: "5 - Severe"
};

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastContainer.appendChild(toast);

    window.setTimeout(() => {
        toast.classList.add("hide");
        toast.addEventListener("transitionend", () => toast.remove(), { once: true });
    }, 3200);
}

async function apiRequest(path) {
    const response = await fetch(`${API_URL}${path}`, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
        throw new Error(data.message || "Request failed.");
    }

    return data;
}

function setLoggedInUser() {
    if (!currentUser) return;

    elements.userInfo.innerHTML = `
        <strong>${escapeHtml(currentUser.full_name)}</strong>
        <br>
        <small>${escapeHtml(currentUser.role)}</small>
    `;

    if (!["System Administrator","Risk Committee Chairman"].includes(currentUser.role)) {
        elements.directorateFilter.value = currentUser.directorate || "";
        elements.directorateFilter.disabled = true;
    }
}

function setLoading(isLoading) {
    state.isLoading = isLoading;
    elements.loadingState.style.display = isLoading ? "block" : "none";
}

async function loadReports() {
    try {
        setLoading(true);

        const [riskData, treatmentData] = await Promise.all([
            apiRequest("/risks"),
            apiRequest("/treatments")
        ]);

        state.risks = riskData.risks || [];
        state.treatmentPlans = treatmentData.treatmentPlans || [];
        updateGeneratedDate();
        renderReport();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to load reports.", "error");
    } finally {
        setLoading(false);
        renderReport();
    }
}

function updateGeneratedDate() {
    elements.generatedDate.textContent = new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    }).format(new Date());
}

function updateStatusOptions() {
    const type = elements.reportType.value;
    const selected = elements.statusFilter.value;

    elements.statusFilter.innerHTML = '<option value="">All Statuses</option>';

    reportConfig[type].statuses.forEach(status => {
        const option = document.createElement("option");
        option.value = status;
        option.textContent = status;
        elements.statusFilter.appendChild(option);
    });

    elements.statusFilter.value = selected;
}

function renderReport() {
    updateStatusOptions();

    const type = elements.reportType.value;
    const config = reportConfig[type];
    const rows = getFilteredRows(type);

    state.reportRows = rows;
    elements.reportTitle.textContent = config.title;
    elements.reportRows.textContent = rows.length;
    elements.criticalRisks.textContent = state.risks.filter(risk => risk.risk_level === "Critical").length;
    elements.openRisks.textContent = state.risks.filter(risk => risk.status !== "Closed").length;
    elements.overdueActions.textContent = state.treatmentPlans.filter(plan => plan.is_overdue || plan.status === "Overdue").length;

    elements.reportHead.innerHTML = `
        <tr>
            ${config.columns.map(([, label]) => `<th>${escapeHtml(label)}</th>`).join("")}
        </tr>
    `;

    elements.reportBody.innerHTML = rows.map(row => `
        <tr>
            ${config.columns.map(([key]) => `<td>${escapeHtml(formatValue(row[key], key))}</td>`).join("")}
        </tr>
    `).join("");

    elements.emptyState.style.display = !state.isLoading && rows.length === 0 ? "block" : "none";
}

function getFilteredRows(type) {
    const keyword = elements.searchInput.value.trim().toLowerCase();
    const directorate = elements.directorateFilter.value;
    const status = elements.statusFilter.value;

    let rows = getReportRows(type);

    if (directorate) {
        rows = rows.filter(row => row.directorate === directorate);
    }

    if (status) {
        rows = rows.filter(row => type === "assessment" ? row.risk_level === status : row.status === status);
    }

    if (keyword) {
        rows = rows.filter(row => Object.values(row).some(value =>
            String(value || "").toLowerCase().includes(keyword)
        ));
    }

    return rows;
}

function getReportRows(type) {
    if (type === "treatment") {
        return state.treatmentPlans.map(plan => ({
            ...plan,
            evidence_status: plan.evidence_file_name || plan.evidence_url ? "Attached" : "Pending"
        }));
    }

    if (type === "assessment") {
        return state.risks.map(risk => ({
            ...risk,
            likelihood_label: likelihoodLabels[risk.likelihood],
            impact_label: impactLabels[risk.impact],
            assessment_decision: getAssessmentDecision(risk)
        }));
    }

    return state.risks;
}

function getAssessmentDecision(risk) {
    if (risk.status === "Accepted" || risk.risk_treatment === "Accept") return "Accepted";
    if (["High", "Critical"].includes(risk.risk_level) && risk.status !== "Closed") return "Escalate";
    return "Monitor";
}

function formatValue(value, key) {
    if (!value) return "";
    if (key.includes("date") || key === "created_at") return formatDate(value);
    if (key === "progress_percent") return `${value}%`;
    return value;
}

function formatDate(value) {
    if (!value) return "";
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    }).format(new Date(value));
}

function downloadFile(filename, content, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}

function exportCsv() {
    const config = reportConfig[elements.reportType.value];
    const rows = state.reportRows;
    const header = config.columns.map(([, label]) => csvEscape(label)).join(",");
    const body = rows.map(row =>
        config.columns.map(([key]) => csvEscape(formatValue(row[key], key))).join(",")
    ).join("\n");

    downloadFile(`${getExportName()}.csv`, `${header}\n${body}`, "text/csv;charset=utf-8;");
    showToast("CSV export generated.");
}

function csvEscape(value) {
    return `"${String(value ?? "").replaceAll('"', '""')}"`;
}

function exportExcel() {
    const html = `
        <html>
            <head><meta charset="UTF-8"></head>
            <body>${document.getElementById("printArea").innerHTML}</body>
        </html>
    `;

    downloadFile(`${getExportName()}.xls`, html, "application/vnd.ms-excel;charset=utf-8;");
    showToast("Excel export generated.");
}

function getExportName() {
    return `${elements.reportType.value}-report-${new Date().toISOString().slice(0, 10)}`;
}

function printReport() {
    window.print();
}

function bindEvents() {
    document.getElementById("logoutBtn").addEventListener("click", () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        window.location.href = "../index.html";
    });

    [
        elements.searchInput,
        elements.directorateFilter,
        elements.statusFilter,
        elements.reportType
    ].forEach(field => {
        field.addEventListener("input", renderReport);
        field.addEventListener("change", renderReport);
    });

    elements.csvBtn.addEventListener("click", exportCsv);
    elements.excelBtn.addEventListener("click", exportExcel);
    elements.printBtn.addEventListener("click", printReport);
    elements.pdfBtn.addEventListener("click", printReport);
}

setLoggedInUser();
bindEvents();
loadReports();
