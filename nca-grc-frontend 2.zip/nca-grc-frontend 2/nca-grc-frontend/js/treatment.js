const API_URL = "http://localhost:3000/api";

const token = localStorage.getItem("token");
const currentUser = JSON.parse(localStorage.getItem("user"));

if (!token) {
    window.location.href = "../index.html";
}

if (window.NCAGRC_ACCESS_DENIED) {
    throw new Error("Access denied.");
}

const STRATEGIES = ["Avoid", "Reduce", "Transfer", "Accept"];
const STATUSES = ["Not Started", "In Progress", "Completed", "Overdue"];

const state = {
    risks: [],
    treatmentPlans: [],
    editingPlanId: null,
    currentPage: 1,
    pageSize: 8,
    isLoading: false
};

const elements = {
    addTreatmentBtn: document.getElementById("addTreatmentBtn"),
    closeModal: document.getElementById("closeModal"),
    closeModalBtn: document.getElementById("closeModalBtn"),
    completedPlans: document.getElementById("completedPlans"),
    directorateFilter: document.getElementById("directorateFilter"),
    emptyState: document.getElementById("emptyState"),
    inProgressPlans: document.getElementById("inProgressPlans"),
    loadingState: document.getElementById("loadingState"),
    modal: document.getElementById("treatmentModal"),
    modalTitle: document.getElementById("modalTitle"),
    nextPage: document.getElementById("nextPage"),
    overduePlans: document.getElementById("overduePlans"),
    pageInfo: document.getElementById("pageInfo"),
    paginationSummary: document.getElementById("paginationSummary"),
    prevPage: document.getElementById("prevPage"),
    saveTreatment: document.getElementById("saveTreatment"),
    searchInput: document.getElementById("searchInput"),
    statusFilter: document.getElementById("statusFilter"),
    table: document.getElementById("treatmentTable"),
    toastContainer: document.getElementById("toastContainer"),
    totalPlans: document.getElementById("totalPlans"),
    userInfo: document.getElementById("userInfo")
};

const fields = {
    risk_id: document.getElementById("risk_id"),
    plan_title: document.getElementById("plan_title"),
    treatment_strategy: document.getElementById("treatment_strategy"),
    action_owner: document.getElementById("action_owner"),
    due_date: document.getElementById("due_date"),
    progress_percent: document.getElementById("progress_percent"),
    progress_value: document.getElementById("progress_value"),
    status: document.getElementById("status"),
    evidence_file_name: document.getElementById("evidence_file_name"),
    evidence_url: document.getElementById("evidence_url"),
    evidence_notes: document.getElementById("evidence_notes")
};

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastContainer.appendChild(toast);

    window.setTimeout(() => {
        toast.classList.add("hide");
        toast.addEventListener("transitionend", () => toast.remove(), { once: true });
    }, 3200);
}

async function apiRequest(path, options = {}) {
    const response = await fetch(`${API_URL}${path}`, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            ...(options.headers || {})
        }
    });

    const data = await response.json().catch(() => ({
        success: false,
        message: "Unexpected server response."
    }));

    if (!response.ok || !data.success) {
        throw new Error(data.message || "Request failed.");
    }

    return data;
}

function setLoggedInUser() {
    if (!currentUser) return;

    elements.userInfo.innerHTML = `
        <strong>${escapeHtml(currentUser.full_name)}</strong>
        <br>
        <small>${escapeHtml(currentUser.role)}</small>
    `;

    if (!["System Administrator","Risk Committee Chairman"].includes(currentUser.role)) {
        elements.directorateFilter.value = currentUser.directorate || "";
        elements.directorateFilter.disabled = true;
    }
    elements.addTreatmentBtn.hidden = !["System Administrator","Risk Champion"].includes(currentUser.role);
}

function setLoading(isLoading) {
    state.isLoading = isLoading;
    elements.loadingState.style.display = isLoading ? "block" : "none";
    elements.saveTreatment.disabled = isLoading;
    elements.addTreatmentBtn.disabled = isLoading;
}

function buildTreatmentQuery() {
    const params = new URLSearchParams();
    const search = elements.searchInput.value.trim();
    const directorate = elements.directorateFilter.value;
    const status = elements.statusFilter.value;

    if (search) params.set("search", search);
    if (directorate) params.set("directorate", directorate);
    if (status) params.set("status", status);

    const query = params.toString();
    return query ? `?${query}` : "";
}

async function loadPageData() {
    try {
        setLoading(true);

        const [risksData, treatmentData] = await Promise.all([
            apiRequest("/risks"),
            apiRequest(`/treatments${buildTreatmentQuery()}`)
        ]);

        state.risks = risksData.risks || [];
        state.treatmentPlans = treatmentData.treatmentPlans || [];
        state.currentPage = 1;

        populateRiskOptions();
        updateStats();
        renderTreatmentPlans();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to load treatment data.", "error");
    } finally {
        setLoading(false);
        renderTreatmentPlans();
    }
}

function populateRiskOptions() {
    const selectedValue = fields.risk_id.value;

    fields.risk_id.innerHTML = '<option value="">Select Risk</option>';

    state.risks.forEach(risk => {
        const option = document.createElement("option");
        option.value = risk.id;
        option.textContent = `${risk.risk_id} - ${risk.risk_title}`;
        fields.risk_id.appendChild(option);
    });

    fields.risk_id.value = selectedValue;
}

function updateStats() {
    elements.totalPlans.textContent = state.treatmentPlans.length;
    elements.inProgressPlans.textContent = state.treatmentPlans.filter(plan => plan.status === "In Progress").length;
    elements.completedPlans.textContent = state.treatmentPlans.filter(plan => plan.status === "Completed").length;
    elements.overduePlans.textContent = state.treatmentPlans.filter(plan => plan.is_overdue || plan.status === "Overdue").length;
}

function getTotalPages() {
    return Math.max(Math.ceil(state.treatmentPlans.length / state.pageSize), 1);
}

function getPaginatedPlans() {
    const start = (state.currentPage - 1) * state.pageSize;
    return state.treatmentPlans.slice(start, start + state.pageSize);
}

function renderTreatmentPlans() {
    const totalPages = getTotalPages();

    if (state.currentPage > totalPages) {
        state.currentPage = totalPages;
    }

    elements.table.innerHTML = "";

    getPaginatedPlans().forEach(plan => {
        const row = document.createElement("tr");
        const statusClass = getStatusClass(plan.status, plan.is_overdue);
        const evidenceLabel = plan.evidence_file_name || plan.evidence_url ? "Attached" : "Pending";

        row.innerHTML = `
            <td>
                <strong>${escapeHtml(plan.risk_code)}</strong>
                <br>
                <small>${escapeHtml(plan.risk_title)}</small>
            </td>
            <td>
                <strong>${escapeHtml(plan.plan_title)}</strong>
                <br>
                <small>${escapeHtml(plan.treatment_strategy)} · ${escapeHtml(plan.directorate)}</small>
            </td>
            <td>${escapeHtml(plan.action_owner)}</td>
            <td>
                <strong>${formatDate(plan.due_date)}</strong>
                ${plan.is_overdue ? '<br><small class="overdue-text">Overdue</small>' : ''}
            </td>
            <td>
                <div class="progress-cell">
                    <div class="progress-bar">
                        <span style="width:${Number(plan.progress_percent || 0)}%"></span>
                    </div>
                    <small>${escapeHtml(plan.progress_percent)}%</small>
                </div>
            </td>
            <td>
                <span class="status ${statusClass}">
                    ${escapeHtml(plan.is_overdue && plan.status !== "Completed" ? "Overdue" : plan.status)}
                </span>
            </td>
            <td>
                <span class="evidence-badge ${evidenceLabel === "Attached" ? "attached" : "pending"}">
                    ${evidenceLabel}
                </span>
            </td>
            <td>
                <div class="row-actions">
                    ${["System Administrator","Risk Champion","Risk Focal Person"].includes(currentUser.role)?`<button class="edit-btn" type="button" data-action="edit" data-id="${plan.id}">Edit</button>`:''}
                    ${currentUser.role==="System Administrator"?`<button class="delete-btn" type="button" data-action="delete" data-id="${plan.id}">Delete</button>`:''}
                </div>
            </td>
        `;

        elements.table.appendChild(row);
    });

    renderPagination();
    elements.emptyState.style.display = !state.isLoading && state.treatmentPlans.length === 0 ? "block" : "none";
}

function renderPagination() {
    const total = state.treatmentPlans.length;
    const totalPages = getTotalPages();
    const start = total === 0 ? 0 : (state.currentPage - 1) * state.pageSize + 1;
    const end = Math.min(state.currentPage * state.pageSize, total);

    elements.paginationSummary.textContent = total === 0
        ? "Showing 0 plans"
        : `Showing ${start}-${end} of ${total} plans`;
    elements.pageInfo.textContent = `Page ${state.currentPage} of ${totalPages}`;
    elements.prevPage.disabled = state.currentPage <= 1;
    elements.nextPage.disabled = state.currentPage >= totalPages;
}

function getStatusClass(status, isOverdue) {
    if (isOverdue && status !== "Completed") return "overdue";
    return String(status || "").toLowerCase().replaceAll(" ", "-");
}

function formatDate(value) {
    if (!value) return "";
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    }).format(new Date(value));
}

function normalizeDateInput(value) {
    if (!value) return "";
    return new Date(value).toISOString().slice(0, 10);
}

function syncProgress(value) {
    const progress = Math.max(0, Math.min(100, Number(value) || 0));
    fields.progress_percent.value = progress;
    fields.progress_value.value = progress;

    if (progress === 100) {
        fields.status.value = "Completed";
    } else if (progress > 0 && fields.status.value === "Not Started") {
        fields.status.value = "In Progress";
    }
}

function resetForm() {
    Object.values(fields).forEach(field => {
        if (field.tagName === "SELECT") {
            field.selectedIndex = 0;
        } else {
            field.value = "";
        }
    });

    fields.progress_percent.value = "0";
    fields.progress_value.value = "0";
    fields.status.value = "Not Started";
}

function openModal(plan = null) {
    resetForm();
    populateRiskOptions();
    state.editingPlanId = plan ? plan.id : null;

    if (plan) {
        fields.risk_id.value = plan.risk_id || "";
        fields.plan_title.value = plan.plan_title || "";
        fields.treatment_strategy.value = plan.treatment_strategy || "";
        fields.action_owner.value = plan.action_owner || "";
        fields.due_date.value = normalizeDateInput(plan.due_date);
        syncProgress(plan.progress_percent || 0);
        fields.status.value = plan.status || "Not Started";
        fields.evidence_file_name.value = plan.evidence_file_name || "";
        fields.evidence_url.value = plan.evidence_url || "";
        fields.evidence_notes.value = plan.evidence_notes || "";
        elements.modalTitle.textContent = "Edit Treatment Plan";
        elements.saveTreatment.textContent = "Update Plan";
    } else {
        elements.modalTitle.textContent = "Add Treatment Plan";
        elements.saveTreatment.textContent = "Save Plan";
    }

    elements.modal.style.display = "flex";
    elements.modal.setAttribute("aria-hidden", "false");
    fields.risk_id.focus();
}

function closeModal() {
    elements.modal.style.display = "none";
    elements.modal.setAttribute("aria-hidden", "true");
    state.editingPlanId = null;
    resetForm();
}

function getFormPayload() {
    return {
        risk_id: Number(fields.risk_id.value),
        plan_title: fields.plan_title.value.trim(),
        treatment_strategy: fields.treatment_strategy.value,
        action_owner: fields.action_owner.value.trim(),
        due_date: fields.due_date.value,
        progress_percent: Number(fields.progress_value.value),
        status: fields.status.value,
        evidence_file_name: fields.evidence_file_name.value.trim(),
        evidence_url: fields.evidence_url.value.trim(),
        evidence_notes: fields.evidence_notes.value.trim()
    };
}

function validateForm(payload) {
    if (!Number.isInteger(payload.risk_id)) return "Select a valid risk.";
    if (!payload.plan_title) return "Treatment plan title is required.";
    if (!STRATEGIES.includes(payload.treatment_strategy)) return "Select a valid treatment strategy.";
    if (!payload.action_owner) return "Action owner is required.";
    if (!payload.due_date) return "Due date is required.";
    if (!Number.isInteger(payload.progress_percent) || payload.progress_percent < 0 || payload.progress_percent > 100) return "Progress must be between 0 and 100.";
    if (!STATUSES.includes(payload.status)) return "Select a valid status.";
    return "";
}

async function saveTreatmentPlan() {
    const payload = getFormPayload();
    const validationError = validateForm(payload);

    if (validationError) {
        showToast(validationError, "error");
        return;
    }

    const isEditing = Boolean(state.editingPlanId);
    const path = isEditing ? `/treatments/${state.editingPlanId}` : "/treatments";
    const method = isEditing ? "PUT" : "POST";

    try {
        setLoading(true);

        const data = await apiRequest(path, {
            method,
            body: JSON.stringify(payload)
        });

        showToast(data.message || "Treatment plan saved successfully.");
        closeModal();
        await loadPageData();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to save treatment plan.", "error");
    } finally {
        setLoading(false);
    }
}

function editTreatmentPlan(id) {
    const plan = state.treatmentPlans.find(item => Number(item.id) === Number(id));

    if (!plan) {
        showToast("Treatment plan not found.", "error");
        return;
    }

    openModal(plan);
}

async function deleteTreatmentPlan(id) {
    const plan = state.treatmentPlans.find(item => Number(item.id) === Number(id));

    if (!plan) {
        showToast("Treatment plan not found.", "error");
        return;
    }

    const confirmed = window.confirm(`Delete treatment plan "${plan.plan_title}"?`);

    if (!confirmed) return;

    try {
        setLoading(true);

        const data = await apiRequest(`/treatments/${id}`, {
            method: "DELETE"
        });

        showToast(data.message || "Treatment plan deleted successfully.");
        await loadPageData();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to delete treatment plan.", "error");
    } finally {
        setLoading(false);
    }
}

function bindEvents() {
    document.getElementById("logoutBtn").addEventListener("click", () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        window.location.href = "../index.html";
    });

    elements.addTreatmentBtn.addEventListener("click", () => openModal());
    elements.closeModal.addEventListener("click", closeModal);
    elements.closeModalBtn.addEventListener("click", closeModal);
    elements.saveTreatment.addEventListener("click", saveTreatmentPlan);

    fields.progress_percent.addEventListener("input", event => syncProgress(event.target.value));
    fields.progress_value.addEventListener("input", event => syncProgress(event.target.value));

    [
        elements.searchInput,
        elements.directorateFilter,
        elements.statusFilter
    ].forEach(field => {
        field.addEventListener("input", loadPageData);
        field.addEventListener("change", loadPageData);
    });

    elements.prevPage.addEventListener("click", () => {
        if (state.currentPage > 1) {
            state.currentPage -= 1;
            renderTreatmentPlans();
        }
    });

    elements.nextPage.addEventListener("click", () => {
        if (state.currentPage < getTotalPages()) {
            state.currentPage += 1;
            renderTreatmentPlans();
        }
    });

    elements.table.addEventListener("click", event => {
        const button = event.target.closest("button[data-action]");

        if (!button) return;

        if (button.dataset.action === "edit") {
            editTreatmentPlan(button.dataset.id);
        }

        if (button.dataset.action === "delete") {
            deleteTreatmentPlan(button.dataset.id);
        }
    });

    elements.modal.addEventListener("click", event => {
        if (event.target === elements.modal) {
            closeModal();
        }
    });
}

setLoggedInUser();
bindEvents();
loadPageData();
