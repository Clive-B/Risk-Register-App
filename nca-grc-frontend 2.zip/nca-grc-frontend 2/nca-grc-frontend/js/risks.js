const API_URL = "http://localhost:3000/api";

const DIRECTORATES = [
    "RIPS",
    "Legal",
    "Regulatory Administration",
    "Consumer Affairs",
    "Corporate Affairs",
    "Finance",
    "Engineering",
    "Information Technology",
    "Procurement and Protocol",
    "Internal Audit",
    "Human Resource",
    "ROD",
    "Administration",
    "Cybersecurity",
    "International Affairs"
];

const CATEGORIES = [
    "Strategic",
    "Operational",
    "Financial",
    "Compliance",
    "Technology",
    "Cybersecurity",
    "Legal",
    "Reputational",
    "Procurement",
    "Human Resource"
];

const TREATMENTS = ["Avoid", "Reduce", "Transfer", "Accept"];
const STATUSES = ["Draft","Submitted","Under Review","Accepted","Returned","Treatment In Progress","Monitoring","Closed"];

const state = {
    risks: [],
    filteredRisks: [],
    editingRiskId: null,
    currentPage: 1,
    pageSize: 8,
    isLoading: false,
    sortKey: "updated_at",
    sortDirection: "desc"
};

const importState = {
    file: null,
    fileData: null,
    preview: null,
    isProcessing: false
};

const token = localStorage.getItem("token");
const currentUser = JSON.parse(localStorage.getItem("user"));

if (!token) {
    window.location.href = "../index.html";
}

if (window.NCAGRC_ACCESS_DENIED) {
    throw new Error("Access denied.");
}

const elements = {
    addRiskBtn: document.getElementById("addRiskBtn"),
    importRiskBtn: document.getElementById("importRiskBtn"),
    moreFiltersBtn: document.getElementById("moreFiltersBtn"),
    clearFiltersBtn: document.getElementById("clearFiltersBtn"),
    activeFiltersCount: document.getElementById("activeFiltersCount"),
    savedFiltersBtn: document.getElementById("savedFiltersBtn"),
    importRiskModal: document.getElementById("importRiskModal"),
    closeImportModal: document.getElementById("closeImportModal"),
    cancelImportBtn: document.getElementById("cancelImportBtn"),
    chooseWorkbookBtn: document.getElementById("chooseWorkbookBtn"),
    riskWorkbookInput: document.getElementById("riskWorkbookInput"),
    importFileName: document.getElementById("importFileName"),
    importFileHelp: document.getElementById("importFileHelp"),
    importProgress: document.getElementById("importProgress"),
    importProgressLabel: document.getElementById("importProgressLabel"),
    importProgressValue: document.getElementById("importProgressValue"),
    importProgressBar: document.getElementById("importProgressBar"),
    importPreview: document.getElementById("importPreview"),
    importSheetMeta: document.getElementById("importSheetMeta"),
    importPreviewHead: document.getElementById("importPreviewHead"),
    importPreviewBody: document.getElementById("importPreviewBody"),
    importValidationErrors: document.getElementById("importValidationErrors"),
    importErrorList: document.getElementById("importErrorList"),
    previewTotal: document.getElementById("previewTotal"),
    previewValid: document.getElementById("previewValid"),
    previewFailed: document.getElementById("previewFailed"),
    importResult: document.getElementById("importResult"),
    confirmImportBtn: document.getElementById("confirmImportBtn"),
    closeModal: document.getElementById("closeModal"),
    closeModalBtn: document.getElementById("closeModalBtn"),
    criticalRisks: document.getElementById("criticalRisks"),
    directorateFilter: document.getElementById("directorateFilter"),
    emptyState: document.getElementById("emptyState"),
    highRisks: document.getElementById("highRisks"),
    levelFilter: document.getElementById("levelFilter"),
    loadingState: document.getElementById("loadingState"),
    modal: document.getElementById("riskModal"),
    modalTitle: document.getElementById("modalTitle"),
    nextPage: document.getElementById("nextPage"),
    openRisks: document.getElementById("openRisks"),
    pageInfo: document.getElementById("pageInfo"),
    paginationSummary: document.getElementById("paginationSummary"),
    prevPage: document.getElementById("prevPage"),
    saveRisk: document.getElementById("saveRisk"),
    searchInput: document.getElementById("searchInput"),
    statusFilter: document.getElementById("statusFilter"),
    submitRisk: document.getElementById("submitRisk"),
    table: document.getElementById("risksTable"),
    toastContainer: document.getElementById("toastContainer"),
    totalRisks: document.getElementById("totalRisks"),
    userInfo: document.getElementById("userInfo"),
    workflowFilter: document.getElementById("workflowFilter")
};

const fields = {
    risk_title: document.getElementById("risk_title"),
    risk_description: document.getElementById("risk_description"),
    risk_category: document.getElementById("risk_category"),
    directorate: document.getElementById("directorate"),
    risk_owner: document.getElementById("risk_owner"),
    risk_treatment: document.getElementById("risk_treatment"),
    likelihood: document.getElementById("likelihood"),
    impact: document.getElementById("impact"),
    inherent_risk_score: document.getElementById("inherent_risk_score"),
    risk_level: document.getElementById("risk_level"),
    residual_risk_score: document.getElementById("residual_risk_score"),
    status: document.getElementById("status"),
    existing_controls: document.getElementById("existing_controls")
};

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function setLoggedInUser() {
    if (!currentUser || !elements.userInfo) return;

    elements.userInfo.innerHTML = `
        <strong>${escapeHtml(currentUser.full_name)}</strong>
        <br>
        <small>${escapeHtml(currentUser.role)}</small>
    `;

    if (!["System Administrator","Risk Committee Chairman"].includes(currentUser.role)) {
        fields.directorate.value = currentUser.directorate || "";
        fields.directorate.disabled = true;
        elements.directorateFilter.value = currentUser.directorate || "";
        elements.directorateFilter.disabled = true;
    }

    if (["Risk Champion","Risk Committee Chairman"].includes(currentUser.role)) {
        elements.addRiskBtn.style.display = "none";
    }

    elements.importRiskBtn.hidden = currentUser.role !== "Risk Focal Person";
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastContainer.appendChild(toast);

    window.setTimeout(() => {
        toast.classList.add("hide");
        toast.addEventListener("transitionend", () => toast.remove(), { once: true });
    }, 3200);
}

function updateActiveFilterCount() {
    const activeFilters = [
        !elements.directorateFilter.disabled && elements.directorateFilter.value,
        elements.levelFilter.value,
        elements.statusFilter.value,
        elements.workflowFilter.value
    ].filter(Boolean).length;

    elements.activeFiltersCount.textContent = activeFilters;
}

function clearAllFilters() {
    elements.searchInput.value = "";
    if (!elements.directorateFilter.disabled) elements.directorateFilter.value = "";
    elements.levelFilter.value = "";
    elements.statusFilter.value = "";
    elements.workflowFilter.value = "";
    state.currentPage = 1;
    updateActiveFilterCount();
    loadRisks();
}

async function apiRequest(path, options = {}) {
    const response = await fetch(`${API_URL}${path}`, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            ...(options.headers || {})
        }
    });

    const data = await response.json().catch(() => ({
        success: false,
        message: "Unexpected server response."
    }));

    if (!response.ok || !data.success) {
        throw new Error(data.message || "Request failed.");
    }

    return data;
}

function resetImportDialog() {
    importState.file = null;
    importState.fileData = null;
    importState.preview = null;
    importState.isProcessing = false;
    elements.riskWorkbookInput.value = "";
    elements.importFileName.textContent = "Choose the official NCA Excel template";
    elements.importFileHelp.textContent = "Accepted formats: .xlsx and .xls. Maximum file size: 8 MB.";
    elements.importProgress.hidden = true;
    elements.importPreview.hidden = true;
    elements.importResult.hidden = true;
    elements.importResult.innerHTML = "";
    elements.confirmImportBtn.disabled = true;
    elements.confirmImportBtn.textContent = "Import Valid Records";
}

function openImportDialog() {
    resetImportDialog();
    elements.importRiskModal.style.display = "flex";
    elements.importRiskModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
}

function closeImportDialog() {
    if (importState.isProcessing) return;
    elements.importRiskModal.style.display = "none";
    elements.importRiskModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
}

function setImportProgress(isVisible, label = "Reading workbook...", percent = 0) {
    elements.importProgress.hidden = !isVisible;
    elements.importProgressLabel.textContent = label;
    elements.importProgressValue.textContent = `${percent}%`;
    elements.importProgressBar.style.width = `${percent}%`;
}

function readWorkbook(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error("The selected workbook could not be read."));
        reader.readAsDataURL(file);
    });
}

function validateWorkbookFile(file) {
    if (!file || !/\.(xlsx|xls)$/i.test(file.name)) return "Only .xlsx and .xls files are allowed.";
    if (file.size > 8 * 1024 * 1024) return "The workbook must be smaller than 8 MB.";
    if (!file.size) return "The selected workbook is empty.";
    return "";
}

function renderImportPreview(preview) {
    const summary = preview.summary;
    elements.importSheetMeta.textContent = `${preview.file_name} • Sheet: ${preview.sheet_name} • Header row: ${preview.header_row}`;
    elements.previewTotal.textContent = summary.total_rows;
    elements.previewValid.textContent = summary.valid_rows;
    elements.previewFailed.textContent = summary.failed_rows;
    elements.importPreviewHead.innerHTML = `<tr><th>Excel Row</th><th>Validation</th>${preview.headers.map(header => `<th>${escapeHtml(header)}</th>`).join("")}</tr>`;
    elements.importPreviewBody.innerHTML = preview.rows.map(row => `
        <tr class="${row.valid ? "preview-valid-row" : "preview-invalid-row"}">
            <td>${row.excel_row}</td>
            <td><span class="preview-status ${row.valid ? "valid" : "invalid"}">${row.valid ? "Valid" : `${row.errors.length} error${row.errors.length === 1 ? "" : "s"}`}</span></td>
            ${preview.headers.map(header => `<td>${escapeHtml(row.values[header])}</td>`).join("")}
        </tr>
    `).join("");

    elements.importErrorList.innerHTML = summary.validation_errors
        .map(error => `<li><strong>Excel row ${error.excel_row}:</strong> ${escapeHtml(error.message)}</li>`)
        .join("");
    elements.importValidationErrors.hidden = summary.validation_errors.length === 0;
    elements.importPreview.hidden = false;
    elements.confirmImportBtn.disabled = summary.valid_rows === 0;
    elements.confirmImportBtn.textContent = `Import ${summary.valid_rows} Valid Record${summary.valid_rows === 1 ? "" : "s"}`;
}

async function previewWorkbook(file) {
    const fileError = validateWorkbookFile(file);
    if (fileError) {
        showToast(fileError, "error");
        elements.riskWorkbookInput.value = "";
        return;
    }

    importState.isProcessing = true;
    elements.importFileName.textContent = file.name;
    elements.importFileHelp.textContent = `${Math.ceil(file.size / 1024)} KB • Validating the template and populated rows`;
    elements.importPreview.hidden = true;
    elements.importResult.hidden = true;
    elements.confirmImportBtn.disabled = true;
    setImportProgress(true, "Reading workbook...", 20);

    try {
        importState.file = file;
        importState.fileData = await readWorkbook(file);
        setImportProgress(true, "Detecting headers and validating rows...", 65);
        const data = await apiRequest("/risks/import/preview", {
            method: "POST",
            body: JSON.stringify({ file_name: file.name, file_data: importState.fileData })
        });
        importState.preview = data.preview;
        setImportProgress(true, "Preview ready", 100);
        renderImportPreview(data.preview);
        window.setTimeout(() => setImportProgress(false), 350);
    } catch (error) {
        importState.file = null;
        importState.fileData = null;
        setImportProgress(false);
        showToast(error.message || "Unable to preview the workbook.", "error");
        elements.importFileHelp.textContent = error.message || "The workbook could not be validated.";
    } finally {
        importState.isProcessing = false;
    }
}

function renderImportResult(summary) {
    elements.importResult.innerHTML = `
        <h3>Import Summary</h3>
        <div class="result-summary">
            <span>Total rows <strong>${summary.total_rows}</strong></span>
            <span>Imported rows <strong>${summary.imported_rows}</strong></span>
            <span>Failed rows <strong>${summary.failed_rows}</strong></span>
            <span>Validation errors <strong>${summary.validation_errors.length}</strong></span>
        </div>
        ${summary.validation_errors.length ? `<ul>${summary.validation_errors.map(error => `<li><strong>Excel row ${error.excel_row}:</strong> ${escapeHtml(error.message)}</li>`).join("")}</ul>` : ""}
    `;
    elements.importResult.hidden = false;
}

async function importValidatedWorkbook() {
    if (!importState.file || !importState.fileData || !importState.preview) return;

    importState.isProcessing = true;
    elements.confirmImportBtn.disabled = true;
    elements.cancelImportBtn.disabled = true;
    elements.chooseWorkbookBtn.disabled = true;
    setImportProgress(true, "Importing valid risk records...", 35);

    try {
        const response = await fetch(`${API_URL}/risks/import`, {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
            body: JSON.stringify({ file_name: importState.file.name, file_data: importState.fileData })
        });
        const data = await response.json().catch(() => ({ success: false, message: "Unexpected server response." }));
        if (!data.summary) throw new Error(data.message || "Unable to import the workbook.");

        setImportProgress(true, "Import complete", 100);
        renderImportResult(data.summary);
        elements.importPreview.hidden = true;
        elements.confirmImportBtn.textContent = "Import Complete";
        showToast(data.message || `${data.summary.imported_rows} risks imported.`, data.summary.imported_rows ? "success" : "error");
        if (data.summary.imported_rows) await loadRisks();
    } catch (error) {
        setImportProgress(false);
        elements.confirmImportBtn.disabled = false;
        showToast(error.message || "Unable to import the workbook.", "error");
    } finally {
        importState.isProcessing = false;
        elements.cancelImportBtn.disabled = false;
        elements.chooseWorkbookBtn.disabled = false;
    }
}

function setLoading(isLoading) {
    state.isLoading = isLoading;
    elements.loadingState.style.display = isLoading ? "block" : "none";
    elements.saveRisk.disabled = isLoading;
    elements.addRiskBtn.disabled = isLoading;
}

function buildQueryString() {
    const params = new URLSearchParams();
    const search = elements.searchInput.value.trim();
    const directorate = elements.directorateFilter.value;
    const riskLevel = elements.levelFilter.value;
    const status = elements.statusFilter.value;
    const workflowStatus = elements.workflowFilter.value;

    if (search) params.set("search", search);
    if (directorate) params.set("directorate", directorate);
    if (riskLevel) params.set("risk_level", riskLevel);
    if (status) params.set("status", status);
    if (workflowStatus) params.set("workflow_status", workflowStatus);

    const query = params.toString();
    return query ? `?${query}` : "";
}

async function loadRisks() {
    try {
        setLoading(true);

        const data = await apiRequest(`/risks${buildQueryString()}`);
        state.risks = data.risks || [];
        state.filteredRisks = state.risks;
        state.currentPage = 1;

        updateStats();
        renderRisks();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to load risks.", "error");
    } finally {
        setLoading(false);
        renderRisks();
    }
}

function updateStats() {
    elements.totalRisks.textContent = state.risks.length;
    elements.openRisks.textContent = state.risks.filter(risk => risk.status !== "Closed").length;
    elements.highRisks.textContent = state.risks.filter(risk => risk.risk_level === "High").length;
    elements.criticalRisks.textContent = state.risks.filter(risk => risk.risk_level === "Critical").length;
}

function getTotalPages() {
    return Math.max(Math.ceil(state.filteredRisks.length / state.pageSize), 1);
}

function getPaginatedRisks() {
    const start = (state.currentPage - 1) * state.pageSize;
    return state.filteredRisks.slice(start, start + state.pageSize);
}

function sortRisks() {
    const direction = state.sortDirection === "asc" ? 1 : -1;
    const numericKeys = ["id", "inherent_risk_score", "residual_risk_score"];

    state.filteredRisks.sort((first, second) => {
        const firstValue = first[state.sortKey] ?? "";
        const secondValue = second[state.sortKey] ?? "";

        if (numericKeys.includes(state.sortKey)) {
            return ((Number(firstValue) || 0) - (Number(secondValue) || 0)) * direction;
        }

        return String(firstValue).localeCompare(String(secondValue)) * direction;
    });
}

function renderRisks() {
    const totalPages = getTotalPages();

    if (state.currentPage > totalPages) {
        state.currentPage = totalPages;
    }

    sortRisks();
    elements.table.innerHTML = "";

    getPaginatedRisks().forEach(risk => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>
                <strong>${escapeHtml(risk.risk_id)}</strong>
                <br>
                <small>${formatDate(risk.created_at)}</small>
            </td>
            <td>
                <strong>${escapeHtml(risk.risk_title)}</strong>
                <br>
                <small>${escapeHtml(risk.risk_category)}</small>
            </td>
            <td>${escapeHtml(risk.directorate)}</td>
            <td>${escapeHtml(risk.risk_owner)}</td>
            <td>
                <span class="score-pill">${escapeHtml(risk.inherent_risk_score)}</span>
                <small>Residual ${escapeHtml(risk.residual_risk_score)}</small>
            </td>
            <td>
                <span class="level-badge ${getLevelClass(risk.risk_level)}">
                    ${escapeHtml(risk.risk_level)}
                </span>
            </td>
            <td>
                <span class="status ${getStatusClass(risk.status)}">
                    ${escapeHtml(risk.status)}
                </span>
            </td>
            <td>
                <span class="status ${getStatusClass(risk.workflow_status || "Draft")}">
                    ${escapeHtml(risk.workflow_status || "Draft")}
                </span>
            </td>
            <td>
                <div class="row-actions">
                    ${getRiskActionButtons(risk)}
                </div>
            </td>
        `;
        elements.table.appendChild(row);
    });

    renderPagination();
    elements.emptyState.style.display = !state.isLoading && state.filteredRisks.length === 0 ? "block" : "none";
}

function getRiskActionButtons(risk) {
    const buttons = [`<button class="edit-btn" type="button" data-action="view" data-id="${risk.id}">View</button>`];
    const workflowStatus = risk.workflow_status || "Draft";

    if (canEditRisk(risk)) {
        buttons.push(`<button class="edit-btn" type="button" data-action="edit" data-id="${risk.id}">Edit</button>`);
    } else if (canMonitorRisk(risk)) {
        buttons.push(`<button class="edit-btn" type="button" data-action="edit" data-id="${risk.id}">Update</button>`);
    }

    if (canReviewRisk(risk)) {
        buttons.push(`<button class="edit-btn" type="button" data-action="approve" data-id="${risk.id}">Approve</button>`);
        buttons.push(`<button class="edit-btn" type="button" data-action="return" data-id="${risk.id}">Return</button>`);
        buttons.push(`<button class="delete-btn" type="button" data-action="reject" data-id="${risk.id}">Reject</button>`);
    }

    if (["System Administrator","Risk Champion","Risk Committee Chairman"].includes(currentUser.role) && workflowStatus === "Monitoring" && risk.status !== "Closed") {
        buttons.push(`<button class="delete-btn" type="button" data-action="delete" data-id="${risk.id}">Close</button>`);
    }

    buttons.push(`<button class="edit-btn" type="button" data-action="history" data-id="${risk.id}">History</button>`);
    buttons.push(`<button class="edit-btn" type="button" data-action="attachments" data-id="${risk.id}">Attachments</button>`);

    return buttons.join("");
}

function canEditRisk(risk) {
    const workflowStatus = risk.workflow_status || "Draft";

    if (currentUser.role === "System Administrator") return true;
    if (currentUser.role !== "Risk Focal Person") return false;

    return Number(risk.created_by) === Number(currentUser.id)
        && ["Draft", "Returned"].includes(workflowStatus);
}

function canMonitorRisk(risk) {
    const workflowStatus = risk.workflow_status || "Draft";

    if (!["Accepted","Treatment In Progress","Monitoring"].includes(workflowStatus)) return false;
    if (currentUser.role === "System Administrator") return true;

    return currentUser.role === "Risk Focal Person" && Number(risk.created_by) === Number(currentUser.id);
}

function canReviewRisk(risk) {
    const workflowStatus = risk.workflow_status || "Draft";

    if (workflowStatus !== "Submitted") return false;
    if (currentUser.role === "System Administrator") return true;

    return currentUser.role === "Risk Champion" && currentUser.directorate === risk.directorate;
}

function renderPagination() {
    const total = state.filteredRisks.length;
    const totalPages = getTotalPages();
    const start = total === 0 ? 0 : (state.currentPage - 1) * state.pageSize + 1;
    const end = Math.min(state.currentPage * state.pageSize, total);

    elements.paginationSummary.textContent = total === 0
        ? "Showing 0 risks"
        : `Showing ${start}-${end} of ${total} risks`;
    elements.pageInfo.textContent = `Page ${state.currentPage} of ${totalPages}`;
    elements.prevPage.disabled = state.currentPage <= 1;
    elements.nextPage.disabled = state.currentPage >= totalPages;
}

function formatDate(value) {
    if (!value) return "";
    return new Intl.DateTimeFormat("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    }).format(new Date(value));
}

function getLevelClass(level) {
    return String(level || "").toLowerCase();
}

function getStatusClass(status) {
    return String(status || "").toLowerCase().replaceAll(" ", "-");
}

function calculateRiskLevel(score) {
    if (score >= 20) return "Critical";
    if (score >= 12) return "High";
    if (score >= 6) return "Medium";
    return "Low";
}

function updateCalculatedFields() {
    const likelihood = Number(fields.likelihood.value) || 0;
    const impact = Number(fields.impact.value) || 0;
    const score = likelihood * impact;

    fields.inherent_risk_score.value = score || 0;
    fields.risk_level.value = calculateRiskLevel(score || 1);

    if (!fields.residual_risk_score.value || Number(fields.residual_risk_score.value) < 1) {
        fields.residual_risk_score.value = score || 1;
    }
}

function resetForm() {
    Object.values(fields).forEach(field => {
        if (field.tagName === "SELECT") {
            field.selectedIndex = 0;
        } else {
            field.value = "";
        }
    });

    fields.inherent_risk_score.value = "0";
    fields.risk_level.value = "Low";
    fields.residual_risk_score.value = "1";
    fields.status.value = "Draft";

    if (currentUser?.role !== "System Administrator") {
        fields.directorate.value = currentUser.directorate || "";
        fields.directorate.disabled = true;
    }
}

function openModal(risk = null) {
    resetForm();
    state.editingRiskId = risk ? risk.id : null;

    if (risk) {
        Object.keys(fields).forEach(key => {
            if (risk[key] !== undefined && fields[key]) {
                fields[key].value = risk[key] ?? "";
            }
        });
        fields.inherent_risk_score.value = risk.inherent_risk_score || 0;
        fields.risk_level.value = risk.risk_level || "Low";
        elements.modalTitle.textContent = "Edit Risk";
        elements.saveRisk.textContent = "Update Risk";
        elements.submitRisk.style.display = currentUser.role === "Risk Focal Person" || currentUser.role === "System Administrator" ? "inline-flex" : "none";
    } else {
        elements.modalTitle.textContent = "Add Risk";
        elements.saveRisk.textContent = "Save Draft";
        elements.submitRisk.style.display = currentUser.role === "Risk Focal Person" || currentUser.role === "System Administrator" ? "inline-flex" : "none";
    }

    updateCalculatedFields();
    elements.modal.style.display = "flex";
    elements.modal.setAttribute("aria-hidden", "false");
    fields.risk_title.focus();
}

function closeModal() {
    elements.modal.style.display = "none";
    elements.modal.setAttribute("aria-hidden", "true");
    state.editingRiskId = null;
    resetForm();
}

function getFormPayload(workflowStatus = "Draft") {
    return {
        risk_title: fields.risk_title.value.trim(),
        risk_description: fields.risk_description.value.trim(),
        risk_category: fields.risk_category.value,
        directorate: fields.directorate.value,
        risk_owner: fields.risk_owner.value.trim(),
        likelihood: Number(fields.likelihood.value),
        impact: Number(fields.impact.value),
        residual_risk_score: Number(fields.residual_risk_score.value),
        existing_controls: fields.existing_controls.value.trim(),
        risk_treatment: fields.risk_treatment.value,
        status: fields.status.value,
        workflow_status: workflowStatus
    };
}

function validateForm(payload) {
    if (!payload.risk_title) return "Risk title is required.";
    if (!payload.risk_description) return "Risk description is required.";
    if (!CATEGORIES.includes(payload.risk_category)) return "Select a valid risk category.";
    if (!DIRECTORATES.includes(payload.directorate)) return "Select a valid division.";
    if (!payload.risk_owner) return "Risk owner is required.";
    if (!Number.isInteger(payload.likelihood) || payload.likelihood < 1 || payload.likelihood > 5) return "Likelihood must be between 1 and 5.";
    if (!Number.isInteger(payload.impact) || payload.impact < 1 || payload.impact > 5) return "Impact must be between 1 and 5.";
    if (!Number.isInteger(payload.residual_risk_score) || payload.residual_risk_score < 1 || payload.residual_risk_score > 25) return "Residual risk score must be between 1 and 25.";
    if (!TREATMENTS.includes(payload.risk_treatment)) return "Select a valid risk treatment.";
    if (!STATUSES.includes(payload.status)) return "Select a valid status.";

    return "";
}

async function saveRisk(workflowStatus = "Draft") {
    const payload = getFormPayload(workflowStatus);
    const validationError = validateForm(payload);

    if (validationError) {
        showToast(validationError, "error");
        return;
    }

    const isEditing = Boolean(state.editingRiskId);
    const path = isEditing ? `/risks/${state.editingRiskId}` : "/risks";
    const method = isEditing ? "PUT" : "POST";

    try {
        setLoading(true);

        const data = await apiRequest(path, {
            method,
            body: JSON.stringify(payload)
        });

        showToast(data.message || (workflowStatus === "Submitted" ? "Risk submitted successfully." : "Risk saved successfully."));
        closeModal();
        await loadRisks();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to save risk.", "error");
    } finally {
        setLoading(false);
    }
}

async function reviewRisk(id, decision) {
    const comments = window.prompt("Review comments");

    if (comments === null) return;

    try {
        setLoading(true);

        const data = await apiRequest(`/risks/${id}/review`, {
            method: "PATCH",
            body: JSON.stringify({
                decision,
                review_comments: comments
            })
        });

        showToast(data.message || "Risk reviewed successfully.");
        await loadRisks();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to review risk.", "error");
    } finally {
        setLoading(false);
    }
}

function editRisk(id) {
    window.location.href = `create-risk.html?id=${encodeURIComponent(id)}`;
}

function viewRisk(id) {
    const risk = state.risks.find(item => Number(item.id) === Number(id));
    if (!risk) {
        showToast("Risk not found.", "error");
        return;
    }

    window.alert([
        `${risk.risk_id} - ${risk.risk_title}`,
        `Division: ${risk.division || risk.directorate}`,
        `Owner: ${risk.risk_owner}`,
        `Category: ${risk.risk_category}`,
        `Inherent Score: ${risk.inherent_risk_score} (${risk.risk_level})`,
        `Workflow: ${risk.workflow_status || "Draft"}`,
        "",
        risk.risk_description || ""
    ].join("\n"));
}

async function showHistory(id) {
    try {
        const data = await apiRequest(`/risks/${id}/history`);
        const lines = [
            ...(data.history || []).map(item => `${formatDate(item.changed_at)} - ${item.action}${item.comment ? `: ${item.comment}` : ""}`),
            ...(data.reviews || []).map(item => `${formatDate(item.reviewed_at)} - ${item.decision}${item.review_comment ? `: ${item.review_comment}` : ""}`),
            ...(data.treatment_updates || []).map(item => `${formatDate(item.created_at)} - Treatment ${item.treatment_status}${item.progress_notes ? `: ${item.progress_notes}` : ""}`)
        ];
        window.alert(lines.length ? lines.join("\n") : "No history recorded for this risk.");
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to load history.", "error");
    }
}

async function showAttachments(id) {
    try {
        const data = await apiRequest(`/risks/${id}/attachments`);
        const lines = (data.attachments || []).map(item => `${item.file_name} (${Math.ceil((item.file_size || 0) / 1024)} KB)`);
        window.alert(lines.length ? lines.join("\n") : "No attachments uploaded for this risk.");
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to load attachments.", "error");
    }
}

async function closeRisk(id) {
    const risk = state.risks.find(item => Number(item.id) === Number(id));

    if (!risk) {
        showToast("Risk not found.", "error");
        return;
    }

    const closureComments = window.prompt(`Closure comments for ${risk.risk_id}`);

    if (closureComments === null) return;
    if (!closureComments.trim()) {
        showToast("Closure comments are required.", "error");
        return;
    }

    try {
        setLoading(true);

        const data = await apiRequest(`/risks/${id}/close`, {
            method: "PATCH",
            body: JSON.stringify({
                closure_date: new Date().toISOString().slice(0, 10),
                closure_comments: closureComments.trim()
            })
        });

        showToast(data.message || "Risk closed successfully.");
        await loadRisks();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to close risk.", "error");
    } finally {
        setLoading(false);
    }
}

function bindEvents() {
    document.getElementById("logoutBtn").addEventListener("click", () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        window.location.href = "../index.html";
    });

    elements.addRiskBtn.addEventListener("click", () => {
        window.location.href = "create-risk.html";
    });
    elements.importRiskBtn.addEventListener("click", () => {
        openImportDialog();
        elements.riskWorkbookInput.click();
    });
    elements.chooseWorkbookBtn.addEventListener("click", () => elements.riskWorkbookInput.click());
    elements.riskWorkbookInput.addEventListener("change", event => {
        const file = event.target.files && event.target.files[0];
        if (file) previewWorkbook(file);
    });
    elements.closeImportModal.addEventListener("click", closeImportDialog);
    elements.cancelImportBtn.addEventListener("click", closeImportDialog);
    elements.confirmImportBtn.addEventListener("click", importValidatedWorkbook);
    elements.importRiskModal.addEventListener("click", event => {
        if (event.target === elements.importRiskModal) closeImportDialog();
    });
    elements.clearFiltersBtn.addEventListener("click", clearAllFilters);
    elements.closeModal.addEventListener("click", closeModal);
    elements.closeModalBtn.addEventListener("click", closeModal);
    elements.saveRisk.addEventListener("click", () => saveRisk("Draft"));
    elements.submitRisk.addEventListener("click", () => saveRisk("Submitted"));

    [fields.likelihood, fields.impact].forEach(field => {
        field.addEventListener("change", updateCalculatedFields);
    });

    [
        elements.searchInput,
        elements.directorateFilter,
        elements.levelFilter,
        elements.statusFilter,
        elements.workflowFilter
    ].forEach(field => {
        field.addEventListener("input", loadRisks);
        field.addEventListener("change", loadRisks);
        field.addEventListener("input", updateActiveFilterCount);
        field.addEventListener("change", updateActiveFilterCount);
    });

    elements.prevPage.addEventListener("click", () => {
        if (state.currentPage > 1) {
            state.currentPage -= 1;
            renderRisks();
        }
    });

    elements.nextPage.addEventListener("click", () => {
        if (state.currentPage < getTotalPages()) {
            state.currentPage += 1;
            renderRisks();
        }
    });

    elements.table.addEventListener("click", event => {
        const button = event.target.closest("button[data-action]");

        if (!button) return;

        if (button.dataset.action === "view") {
            viewRisk(button.dataset.id);
        }

        if (button.dataset.action === "edit") {
            editRisk(button.dataset.id);
        }

        if (button.dataset.action === "history") {
            showHistory(button.dataset.id);
        }

        if (button.dataset.action === "attachments") {
            showAttachments(button.dataset.id);
        }

        if (button.dataset.action === "delete") {
            closeRisk(button.dataset.id);
        }

        if (["approve", "reject", "return"].includes(button.dataset.action)) {
            reviewRisk(button.dataset.id, button.dataset.action);
        }
    });

    document.querySelectorAll("th[data-sort]").forEach(header => {
        header.addEventListener("click", () => {
            const key = header.dataset.sort;

            if (state.sortKey === key) {
                state.sortDirection = state.sortDirection === "asc" ? "desc" : "asc";
            } else {
                state.sortKey = key;
                state.sortDirection = "asc";
            }

            renderRisks();
        });
    });

    elements.modal.addEventListener("click", event => {
        if (event.target === elements.modal) {
            closeModal();
        }
    });
}

setLoggedInUser();
updateActiveFilterCount();
bindEvents();
loadRisks();
