window.NCAGRC = (() => {
    const API_URL = "http://localhost:3000/api";

    const roles = {
    ADMIN: "System Administrator",
    CHAIRMAN: "Risk Committee Chairman",
    CHAMPION: "Risk Champion",
    FOCAL: "Risk Focal Person"
};

    const pageAccess = {
        dashboard: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION,roles.FOCAL],
        users: [roles.ADMIN],
        risks: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION,roles.FOCAL],
        createRisk: [roles.ADMIN, roles.FOCAL],
        pendingApprovals: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION],
        myApprovals: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION,roles.FOCAL],
        actionCentre: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION,roles.FOCAL],
        actionHistory: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION,roles.FOCAL],
        approvalDetails: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION,roles.FOCAL],
        assessment: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION],
        treatment: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION,roles.FOCAL],
        reports: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION],
        communication: [roles.ADMIN],
        executiveAnalytics: [roles.ADMIN,roles.CHAIRMAN],
        boardDashboard: [roles.ADMIN,roles.CHAIRMAN],
        accessDenied: [roles.ADMIN,roles.CHAIRMAN,roles.CHAMPION,roles.FOCAL]
    };

    const sidebars = {
        [roles.ADMIN]: [
            ["Dashboard", "nca-grc-risk-register.html", "dashboard"],
            ["Action Centre", "pages/action-centre.html", "actionCentre"],
            ["User Management", "pages/users.html", "users"],
            ["Administration · Communication Centre", "pages/communication-centre.html", "communication"],
            ["Executive Analytics", "pages/executive-analytics.html", "executiveAnalytics"],
            ["Board Dashboard", "pages/board-dashboard.html", "boardDashboard"],
            ["Risk Register", "pages/risks.html", "risks"],
            ["Create Risk", "pages/create-risk.html", "createRisk"],
            ["Pending Approvals", "pages/pending-approvals.html", "pendingApprovals"],
            ["My Approvals", "pages/my-approvals.html", "myApprovals"],
            ["Analytics", "pages/assessment.html", "assessment"],
            ["Treatment Plans", "pages/treatment.html", "treatment"],
            ["Reports", "pages/reports.html", "reports"]
        ],
        [roles.CHAMPION]: [
            ["Dashboard", "nca-grc-risk-register.html", "dashboard"],
            ["Action Centre", "pages/action-centre.html", "actionCentre"],
            ["Risk Register", "pages/risks.html", "risks"],
            ["Pending Approvals", "pages/pending-approvals.html", "pendingApprovals"],
            ["My Approvals", "pages/my-approvals.html", "myApprovals"],
            ["Risk Heat Map", "pages/assessment.html", "assessment"],
            ["Treatment Plans", "pages/treatment.html", "treatment"],
            ["Reports", "pages/reports.html", "reports"]
        ],
        [roles.FOCAL]: [
            ["Dashboard", "nca-grc-risk-register.html", "dashboard"],
            ["Action Centre", "pages/action-centre.html", "actionCentre"],
            ["Risk Register", "pages/risks.html", "risks"],
            ["Create Risk", "pages/create-risk.html", "createRisk"],
            ["My Approvals", "pages/my-approvals.html", "myApprovals"],
            ["Treatment Plans", "pages/treatment.html", "treatment"]
        ],
        [roles.CHAIRMAN]: [["Enterprise Dashboard","pages/executive-analytics.html","executiveAnalytics"],["Action Centre","pages/action-centre.html","actionCentre"],["Risk Register","pages/risks.html","risks"],["High & Critical Reviews","pages/pending-approvals.html","pendingApprovals"],["Treatment Plans","pages/treatment.html","treatment"],["Enterprise Heat Map","pages/assessment.html","assessment"],["Executive Reports","pages/reports.html","reports"]]
    };

    function getToken() {
        return localStorage.getItem("token");
    }

    function getUser() {
        try {
            return JSON.parse(localStorage.getItem("user"));
        } catch (error) {
            return null;
        }
    }

    async function logout(loginPath = "index.html") {
        const token = getToken();
        if (token) { try { await fetch(`${API_URL}/auth/logout`, { method: "POST", headers: { Authorization: `Bearer ${token}` } }); } catch (_) {} }
        localStorage.removeItem("token");
        localStorage.removeItem("refreshToken");
        localStorage.removeItem("user");
        window.location.href = loginPath;
    }

    function getPageKey() {
        const file = window.location.pathname.split("/").pop() || "nca-grc-risk-register.html";

        if (file === "nca-grc-risk-register.html") return "dashboard";
        if (file === "users.html") return "users";
        if (file === "risks.html") return "risks";
        if (file === "create-risk.html") return "createRisk";
        if (file === "pending-approvals.html") return "pendingApprovals";
        if (file === "my-approvals.html") return "myApprovals";
        if (file === "action-centre.html") return "actionCentre";
        if (file === "action-history.html") return "actionHistory";
        if (file === "approval-details.html") return "approvalDetails";
        if (file === "assessment.html") return "assessment";
        if (file === "treatment.html") return "treatment";
        if (file === "reports.html") return "reports";
        if (file === "communication-centre.html") return "communication";
        if (file === "executive-analytics.html") return "executiveAnalytics";
        if (file === "board-dashboard.html") return "boardDashboard";
        if (file === "access-denied.html") return "accessDenied";
        return "dashboard";
    }

    function getPathPrefix() {
        return window.location.pathname.includes("/pages/") ? "../" : "";
    }

    function resolvePath(path) {
        return `${getPathPrefix()}${path}`;
    }

    function dashboardPath() {
        const user = getUser();
        if (user?.role === roles.CHAIRMAN) {
            return resolvePath("pages/executive-analytics.html");
        }
        return resolvePath("nca-grc-risk-register.html");
    }

    function canAccess(pageKey, role) {
        return Boolean(pageAccess[pageKey]?.includes(role));
    }

    function isKnownRole(role) {
        return Object.values(roles).includes(role);
    }

    async function apiRequest(path, options = {}) {
        const url = `${API_URL}${path.startsWith('/') ? path : `/${path}`}`;
        let response;
        let body = '';
        try {
            response = await fetch(url, {
                ...options,
                headers: {
                    ...(options.body ? { "Content-Type": "application/json" } : {}),
                    ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
                    ...(options.headers || {})
                }
            });
            body = await response.text();
            const type = response.headers.get('content-type') || '';
            if (!type.toLowerCase().includes('application/json')) {
                console.error('API request failed', { url, status: response.status, contentType: type, responseBody: body });
                throw new Error(`API returned ${type || 'an unknown content type'} instead of JSON for ${path}. Verify that the Express API is running on port 3000.`);
            }
            let payload;
            try { payload = JSON.parse(body); }
            catch (error) {
                console.error('API JSON parsing failed', { url, status: response.status, contentType: type, responseBody: body });
                throw new Error(`API returned malformed JSON for ${path}.`);
            }
            if (!response.ok || payload.success !== true) {
                console.error('API request failed', { url, status: response.status, contentType: type, responseBody: body });
                throw new Error(payload.message || `Request failed with status ${response.status}.`);
            }
            return payload.data !== undefined ? payload.data : payload;
        } catch (error) {
            if (!response) console.error('API connection failed', { url, status: 0, contentType: '', responseBody: '', error: error.message });
            throw error;
        }
    }

    async function auditClientEvent(payload) {
        const token = getToken();

        if (!token) return;

        try {
            await fetch(`${API_URL}/audit-logs/client`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(payload)
            });
        } catch (error) {
            console.error("Client audit failed:", error);
        }
    }

    return {
        API_URL,
        roles,
        sidebars,
        getToken,
        getUser,
        logout,
        getPageKey,
        getPathPrefix,
        resolvePath,
        dashboardPath,
        canAccess,
        isKnownRole,
        apiRequest,
        auditClientEvent
    };
})();
