const API_URL = "http://localhost:3000/api";

const ROLES = [
    "System Administrator",
    "Risk Committee Chairman",
    "Risk Champion",
    "Risk Focal Person"
];
const GLOBAL_ROLES = ["System Administrator","Risk Committee Chairman"];

const DIRECTORATES = [
    "RIPS",
    "Legal",
    "Regulatory Administration",
    "Consumer Affairs",
    "Corporate Affairs",
    "Finance",
    "Engineering",
    "Information Technology",
    "Procurement and Protocol",
    "Internal Audit",
    "Human Resource",
    "ROD",
    "Administration",
    "Cybersecurity",
    "International Affairs"
];

const NCA_EMAIL_PATTERN = /^[a-z0-9]+(?:[._%+-][a-z0-9]+)*@nca\.org\.gh$/i;
const NCA_PHONE_PATTERN = /^(?:020|024|025|026|027|050|053|054|055|056|057|059)\d{7}$/;

const state = {
    users: [],
    filteredUsers: [],
    editingUserId: null,
    resettingUserId: null,
    currentPage: 1,
    pageSize: 8,
    isLoading: false
};

const token = localStorage.getItem("token");

if (!token) {
    window.location.href = "../index.html";
}

if (window.NCAGRC_ACCESS_DENIED) {
    throw new Error("Access denied.");
}

const elements = {
    addUserBtn: document.getElementById("addUserBtn"),
    closeModal: document.getElementById("closeModal"),
    closeModalBtn: document.getElementById("closeModalBtn"),
    emptyState: document.getElementById("emptyState"),
    loadingState: document.getElementById("loadingState"),
    modal: document.getElementById("userModal"),
    modalTitle: document.getElementById("modalTitle"),
    nextPage: document.getElementById("nextPage"),
    pageInfo: document.getElementById("pageInfo"),
    paginationSummary: document.getElementById("paginationSummary"),
    prevPage: document.getElementById("prevPage"),
    saveUser: document.getElementById("saveUser"),
    searchInput: document.getElementById("searchInput"),
    statusGroup: document.getElementById("statusGroup"),
    divisionGroup: document.getElementById("divisionGroup"),
    globalScopeGroup: document.getElementById("globalScopeGroup"),
    table: document.getElementById("usersTable"),
    toastContainer: document.getElementById("toastContainer"),
    userInfo: document.getElementById("userInfo")
};

const fields = {
    staff_id: document.getElementById("staff_id"),
    full_name: document.getElementById("full_name"),
    email: document.getElementById("email"),
    phone: document.getElementById("phone"),
    role: document.getElementById("role"),
    directorate: document.getElementById("directorate"),
    position: document.getElementById("position"),
    password: document.getElementById("password"),
    force_password_change: document.getElementById("force_password_change"),
    status: document.getElementById("status")
};

function setLoggedInUser() {
    const currentUser = JSON.parse(localStorage.getItem("user"));

    if (!currentUser || !elements.userInfo) return;

    elements.userInfo.innerHTML = `
        <strong>${escapeHtml(currentUser.full_name)}</strong>
        <br>
        <small>${escapeHtml(currentUser.role)}</small>
    `;
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;

    elements.toastContainer.appendChild(toast);

    window.setTimeout(() => {
        toast.classList.add("hide");
        toast.addEventListener("transitionend", () => toast.remove(), { once: true });
    }, 3200);
}

async function apiRequest(path, options = {}) {
    const response = await fetch(`${API_URL}${path}`, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            ...(options.headers || {})
        }
    });

    const data = await response.json().catch(() => ({
        success: false,
        message: "Unexpected server response."
    }));

    if (!response.ok || !data.success) {
        throw new Error(data.message || "Request failed.");
    }

    return data;
}

function setLoading(isLoading) {
    state.isLoading = isLoading;
    elements.loadingState.style.display = isLoading ? "block" : "none";
    elements.saveUser.disabled = isLoading;
    elements.addUserBtn.disabled = isLoading;
}

async function loadUsers() {
    try {
        setLoading(true);

        const data = await apiRequest("/users");
        state.users = data.users || [];

        applySearch();
        updateStats();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to load users.", "error");
    } finally {
        setLoading(false);
        renderUsers();
    }
}

function updateStats() {
    document.getElementById("totalUsers").textContent = state.users.length;
    document.getElementById("totalAdmins").textContent =
        state.users.filter(user => user.role === "System Administrator").length;
    document.getElementById("totalChampions").textContent =
        state.users.filter(user => user.role === "Risk Champion").length;
    document.getElementById("totalFocals").textContent =
        state.users.filter(user => user.role === "Risk Focal Person").length;
}

function applySearch() {
    const keyword = elements.searchInput.value.trim().toLowerCase();

    state.filteredUsers = state.users.filter(user => {
        const values = [
            user.staff_id,
            user.full_name,
            user.email,
            user.role,
            user.directorate,
            user.status
        ];

        return values.some(value => String(value || "").toLowerCase().includes(keyword));
    });

    state.currentPage = 1;
    renderUsers();
}

function getPaginatedUsers() {
    const start = (state.currentPage - 1) * state.pageSize;
    return state.filteredUsers.slice(start, start + state.pageSize);
}

function getTotalPages() {
    return Math.max(Math.ceil(state.filteredUsers.length / state.pageSize), 1);
}

function renderUsers() {
    const totalPages = getTotalPages();

    if (state.currentPage > totalPages) {
        state.currentPage = totalPages;
    }

    const paginatedUsers = getPaginatedUsers();
    elements.table.innerHTML = "";

    paginatedUsers.forEach(user => {
        const row = document.createElement("tr");
        const initials = getInitials(user.full_name);
        const roleClass = getRoleClass(user.role);
        const statusClass = String(user.status).toLowerCase() === "active" ? "active" : "inactive";
        const divisionLabel = user.role === "System Administrator"
            ? "All Divisions"
            : (user.division || user.directorate || "—");

        row.innerHTML = `
            <td>${escapeHtml(user.staff_id)}</td>
            <td>${escapeHtml(user.full_name)}</td>
            <td>${escapeHtml(user.email)}</td>
            <td>${escapeHtml(divisionLabel)}</td>
            <td>${escapeHtml(user.position || "—")}</td>
            <td><div class="user-profile"><div class="avatar">${escapeHtml(initials)}</div><div><strong>${escapeHtml(user.full_name)}</strong><br><small>${escapeHtml(user.email)}</small></div></div><span class="role-badge ${roleClass}">${escapeHtml(user.role)}</span></td>
            <td>
                <span class="status ${statusClass}">
                    ${escapeHtml(user.activation_status || user.status)}
                </span>
            </td>
            <td>${escapeHtml(user.email_status || "Queued")}</td>
            <td>${user.last_login ? new Date(user.last_login).toLocaleString() : "Never"}</td>
            <td>${escapeHtml(user.password_status)}</td>
            <td>${escapeHtml(user.force_password_change || (user.must_change_password ? "Yes" : "No"))}</td>
            <td>
                <div class="row-actions">
                    <button class="edit-btn" type="button" data-action="view" data-id="${user.id}">View User</button>
                    <button class="edit-btn" type="button" data-action="edit" data-id="${user.id}">
                        Edit
                    </button>
                    <button class="edit-btn" type="button" data-action="reset" data-id="${user.id}">Reset Password</button>
                    <button class="edit-btn" type="button" data-action="generate" data-id="${user.id}">Generate New Temporary Password</button>
                    <button class="edit-btn" type="button" data-action="resend" data-id="${user.id}">Resend Welcome Email</button>
                    <button class="edit-btn" type="button" data-action="activate" data-id="${user.id}">Activate</button>
                    <button class="edit-btn" type="button" data-action="lock" data-id="${user.id}">Lock</button>
                    <button class="edit-btn" type="button" data-action="unlock" data-id="${user.id}" ${user.locked_until ? '' : 'disabled'}>Unlock</button>
                    <button class="edit-btn" type="button" data-action="audit" data-id="${user.id}">Audit History</button>
                    <button class="delete-btn" type="button" data-action="delete" data-id="${user.id}">
                        Deactivate
                    </button>
                </div>
            </td>
        `;

        elements.table.appendChild(row);
    });

    renderPagination();
    elements.emptyState.style.display = !state.isLoading && state.filteredUsers.length === 0 ? "block" : "none";
}

function renderPagination() {
    const total = state.filteredUsers.length;
    const totalPages = getTotalPages();
    const start = total === 0 ? 0 : (state.currentPage - 1) * state.pageSize + 1;
    const end = Math.min(state.currentPage * state.pageSize, total);

    elements.paginationSummary.textContent = total === 0
        ? "Showing 0 users"
        : `Showing ${start}-${end} of ${total} users`;

    elements.pageInfo.textContent = `Page ${state.currentPage} of ${totalPages}`;
    elements.prevPage.disabled = state.currentPage <= 1;
    elements.nextPage.disabled = state.currentPage >= totalPages;
}

function getInitials(fullName) {
    return String(fullName || "")
        .split(" ")
        .filter(Boolean)
        .map(name => name[0])
        .join("")
        .substring(0, 2)
        .toUpperCase();
}

function getRoleClass(role) {
    if (role === "System Administrator") return "admin-role";
    if (role === "Risk Champion") return "champion-role";
    if (role === "Risk Focal Person") return "focal-role";
    return "";
}

function resetForm() {
    Object.values(fields).forEach(field => {
        if (field.tagName === "SELECT") {
            field.selectedIndex = 0;
        } else {
            field.value = "";
        }
    });

    fields.password.value = "";
    fields.force_password_change.value = "true";
    fields.status.value = "Active";
    updateRoleScope();
}

function updateRoleScope() {
    const isSystemAdministrator = GLOBAL_ROLES.includes(fields.role.value);
    elements.divisionGroup.hidden = isSystemAdministrator;
    elements.globalScopeGroup.hidden = !isSystemAdministrator;
    fields.directorate.disabled = isSystemAdministrator;
    fields.directorate.required = !isSystemAdministrator;

    if (isSystemAdministrator) fields.directorate.value = "";
}

function openModal(user = null) {
    resetForm();
    state.editingUserId = user ? user.id : null;

    if (user) {
        fields.staff_id.value = user.staff_id || "";
        fields.full_name.value = user.full_name || "";
        fields.email.value = user.email || "";
        fields.phone.value = user.phone || "";
        fields.role.value = user.role || "";
        fields.directorate.value = user.directorate || "";
        fields.position.value = user.position || "";
        fields.status.value = user.status === "Disabled" ? "Inactive" : (user.status || "Active");
        fields.password.value = "";
        updateRoleScope();
        elements.modalTitle.textContent = "Edit User";
        elements.saveUser.textContent = "Update User";
        elements.statusGroup.style.display = "flex";
    } else {
        elements.modalTitle.textContent = "Add New User";
        elements.saveUser.textContent = "Save User";
        elements.statusGroup.style.display = "none";
    }

    elements.modal.style.display = "flex";
    elements.modal.setAttribute("aria-hidden", "false");
    fields.full_name.focus();
}

function closeModal() {
    elements.modal.style.display = "none";
    elements.modal.setAttribute("aria-hidden", "true");
    state.editingUserId = null;
    resetForm();
}

function getFormPayload() {
    const isSystemAdministrator = GLOBAL_ROLES.includes(fields.role.value);
    const division = isSystemAdministrator ? null : fields.directorate.value;

    return {
        full_name: fields.full_name.value.trim(),
        email: fields.email.value.trim().toLowerCase(),
        phone: fields.phone.value.trim(),
        role: fields.role.value,
        directorate: division,
        position: fields.position.value.trim(),
        division,
        status: fields.status.value || "Active",
        force_password_change: true
    };
}

function validateForm(payload) {
    if (!payload.full_name) return "Full name is required.";
    if (!payload.email) return "Email is required.";
    if (!NCA_EMAIL_PATTERN.test(payload.email)) return "Only official NCA email addresses (@nca.org.gh) are permitted.";
    if (!ROLES.includes(payload.role)) return "Select a valid role.";
    if (!GLOBAL_ROLES.includes(payload.role) && !DIRECTORATES.includes(payload.directorate)) return "Select a valid division.";
    if (!payload.phone) return "Phone number is required.";
    if (!NCA_PHONE_PATTERN.test(payload.phone)) return "Phone number must be exactly 10 digits and start with an approved network code.";

    return "";
}

function openResetModal(id){const user=state.users.find(item=>Number(item.id)===Number(id));if(!user)return;state.resettingUserId=id;document.getElementById('resetUserName').textContent=user.full_name;document.getElementById('resetUserDetails').textContent=`${user.email} · ${user.role}`;document.getElementById('resetModal').style.display='flex';}
function closeResetModal(){document.getElementById('resetModal').style.display='none';state.resettingUserId=null;document.getElementById('adminNewPassword').value='';document.getElementById('adminConfirmPassword').value='';}
async function adminReset(){try{setLoading(true);const data=await apiRequest(`/users/${state.resettingUserId}/reset-password`,{method:'PUT',body:JSON.stringify({newPassword:document.getElementById('adminNewPassword').value,confirmPassword:document.getElementById('adminConfirmPassword').value,forceChange:document.getElementById('forceChange').checked})});showToast(data.message);closeResetModal();await loadUsers();}catch(e){showToast(e.message,'error')}finally{setLoading(false)}}
async function unlockUser(id){try{const data=await apiRequest(`/users/${id}/unlock`,{method:'PUT'});showToast(data.message);await loadUsers()}catch(e){showToast(e.message,'error')}}
async function accountAction(id,action){try{const data=await apiRequest(`/users/${id}/account/${action}`,{method:'PUT'});showToast(data.message);await loadUsers()}catch(e){showToast(e.message,'error')}}
async function viewAuditHistory(id){try{const data=await apiRequest(`/users/${id}/audit-history`);const lines=(data.auditLogs||[]).map(log=>`${new Date(log.created_at).toLocaleString()} — ${log.action} (${log.status})`);window.alert(lines.length?lines.join('\n'):'No audit history found.')}catch(e){showToast(e.message,'error')}}
async function generateTemporaryPassword(id,confirmed=false){if(!confirmed&&!window.confirm('Generate a new temporary password and email it to this user? Existing sessions will be revoked.'))return;try{const data=await apiRequest(`/users/${id}/generate-temporary-password`,{method:'POST'});showToast(data.message);await loadUsers()}catch(e){showToast(e.message,'error')}}
function viewUser(id){const user=state.users.find(item=>Number(item.id)===Number(id));if(!user)return;window.alert([`Name: ${user.full_name}`,`Email: ${user.email}`,`Division: ${user.division||user.directorate||'All Divisions'}`,`Role: ${user.role}`,`Activation: ${user.activation_status||user.status}`,`Password: ${user.password_status}`,`Email: ${user.email_status}`,`Last Login: ${user.last_login?new Date(user.last_login).toLocaleString():'Never'}`].join('\n'))}
async function resendWelcomeEmail(id){if(!window.confirm('For security, resending creates a new temporary password, revokes existing sessions, and emails the new credential. Continue?'))return;await generateTemporaryPassword(id,true)}

async function saveUser() {
    const payload = getFormPayload();
    const validationError = validateForm(payload);

    if (validationError) {
        showToast(validationError, "error");
        return;
    }

    const isEditing = Boolean(state.editingUserId);
    const path = isEditing ? `/users/${state.editingUserId}` : "/users";
    const method = isEditing ? "PUT" : "POST";

    try {
        setLoading(true);

        const data = await apiRequest(path, {
            method,
            body: JSON.stringify(payload)
        });

        showToast(data.message || "User saved successfully.");
        closeModal();
        await loadUsers();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to save user.", "error");
    } finally {
        setLoading(false);
    }
}

function editUser(id) {
    const user = state.users.find(item => Number(item.id) === Number(id));

    if (!user) {
        showToast("User not found.", "error");
        return;
    }

    openModal(user);
}

async function deleteUser(id) {
    const user = state.users.find(item => Number(item.id) === Number(id));

    if (!user) {
        showToast("User not found.", "error");
        return;
    }

    const confirmed = window.confirm(`Deactivate ${user.full_name}?`);

    if (!confirmed) return;

    try {
        setLoading(true);

        const data = await apiRequest(`/users/${id}`, {
            method: "DELETE"
        });

        showToast(data.message || "User deactivated successfully.");
        await loadUsers();
    } catch (error) {
        console.error(error);
        showToast(error.message || "Unable to deactivate user.", "error");
    } finally {
        setLoading(false);
    }
}

function bindEvents() {
    document.getElementById("logoutBtn").addEventListener("click", () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        window.location.href = "../index.html";
    });

    elements.addUserBtn.addEventListener("click", () => openModal());
    elements.closeModal.addEventListener("click", closeModal);
    elements.closeModalBtn.addEventListener("click", closeModal);
    elements.saveUser.addEventListener("click", saveUser);
    fields.role.addEventListener("change", updateRoleScope);
    elements.searchInput.addEventListener("input", applySearch);
    document.getElementById('closeResetModal').addEventListener('click',closeResetModal);
    document.getElementById('cancelAdminReset').addEventListener('click',closeResetModal);
    document.getElementById('confirmAdminReset').addEventListener('click',adminReset);

    elements.prevPage.addEventListener("click", () => {
        if (state.currentPage > 1) {
            state.currentPage -= 1;
            renderUsers();
        }
    });

    elements.nextPage.addEventListener("click", () => {
        if (state.currentPage < getTotalPages()) {
            state.currentPage += 1;
            renderUsers();
        }
    });

    elements.table.addEventListener("click", event => {
        const button = event.target.closest("button[data-action]");

        if (!button) return;

        const id = button.dataset.id;

        if (button.dataset.action === "edit") {
            editUser(id);
        }

        if (button.dataset.action === "delete") {
            deleteUser(id);
        }
        if(button.dataset.action==='reset')openResetModal(id);
        if(button.dataset.action==='unlock')unlockUser(id);
        if(['activate','lock'].includes(button.dataset.action))accountAction(id,button.dataset.action);
        if(button.dataset.action==='audit')viewAuditHistory(id);
        if(button.dataset.action==='generate')generateTemporaryPassword(id);
        if(button.dataset.action==='view')viewUser(id);
        if(button.dataset.action==='resend')resendWelcomeEmail(id);
    });

    elements.modal.addEventListener("click", event => {
        if (event.target === elements.modal) {
            closeModal();
        }
    });
}

setLoggedInUser();
bindEvents();
loadUsers();
