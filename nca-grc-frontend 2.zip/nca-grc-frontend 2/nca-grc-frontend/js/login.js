const API_URL = "http://localhost:3000/api";

const loginForm = document.getElementById("loginForm");

localStorage.removeItem("token");
localStorage.removeItem("user");
localStorage.removeItem("refreshToken");

const forgotModal=document.getElementById('forgotModal');
document.getElementById('forgotPasswordLink').addEventListener('click',e=>{e.preventDefault();forgotModal.style.display='flex';document.getElementById('resetEmail').focus();});
document.getElementById('cancelReset').addEventListener('click',()=>{forgotModal.style.display='none';});
document.getElementById('sendReset').addEventListener('click',async()=>{
    const email=document.getElementById('resetEmail').value.trim();const message=document.getElementById('resetMessage');
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){message.textContent='Enter a valid email address.';return;}
    const button=document.getElementById('sendReset');button.disabled=true;button.textContent='Sending...';
    try{const response=await fetch(`${API_URL}/auth/forgot-password`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email})});const data=await response.json();message.textContent=data.message||'If the address is registered, a reset link will be sent.';}catch(_){message.textContent='Unable to process the request. Please try again.';}finally{button.disabled=false;button.textContent='Send Reset Link';}
});

loginForm.addEventListener("submit", async function (e) {

    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try {

        const response = await fetch(`${API_URL}/auth/login`, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                email,
                password
            })

        });

        const data = await response.json();

        if (!data.success) {

            alert(data.message);
            return;

        }

        // Save token
        localStorage.setItem("token", data.token);
        localStorage.setItem("refreshToken", data.refreshToken);

        // Save user
        localStorage.setItem("user", JSON.stringify(data.user));

        // Redirect to the role-aware, personalized dashboard shell.
        if (data.mustChangePassword) {
            window.location.href = 'change-password.html';
            return;
        }
        let landing = window.NCAGRC.dashboardPath();
        try {
            const preferences = await fetch(`${API_URL}/executive-analytics/preferences`, {
                headers: { Authorization: `Bearer ${data.token}` }
            });
            if (preferences.ok) {
                const payload = await preferences.json();
                if (payload.preferences?.default_dashboard === 'Board') landing = 'pages/board-dashboard.html';
                if (payload.preferences?.default_dashboard === 'Executive') landing = 'pages/executive-analytics.html';
                if (payload.preferences?.default_dashboard === 'Operational') landing = 'nca-grc-risk-register.html';
            }
        } catch (_) {}
        window.location.href = landing;

    } catch (err) {

        console.error(err);

        alert("Server connection failed.");

    }

});
